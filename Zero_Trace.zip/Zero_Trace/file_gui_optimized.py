"""
File-Level Secure Deletion GUI (Optimized)
Fixes freezing issues with proper thread management and progress tracking
"""

import sys
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from file_secure_wipe_optimized import FileSecureWipe
import json

class FileWipeThread(QThread):
    progress_updated = pyqtSignal(str)
    wipe_completed = pyqtSignal(dict)
    file_progress = pyqtSignal(int, int)  # current, total
    single_file_progress = pyqtSignal(int)  # percentage for single file
    
    def __init__(self, file_paths, passes):
        super().__init__()
        self.file_paths = file_paths
        self.passes = passes
        self._stop_requested = False
        self.wiper = FileSecureWipe()
    
    def stop(self):
        self._stop_requested = True
        self.wiper.cancel_operation()
    
    def run(self):
        try:
            if len(self.file_paths) == 1:
                self.progress_updated.emit(f"Securely deleting: {os.path.basename(self.file_paths[0])}")
                
                # Emit progress updates during single file deletion
                for i in range(self.passes):
                    if self._stop_requested:
                        break
                    self.single_file_progress.emit(int((i + 1) * 100 / (self.passes + 2)))
                    
                result = self.wiper.secure_delete_file(self.file_paths[0], self.passes)
                
                if not self._stop_requested:
                    self.single_file_progress.emit(100)
                    self.wipe_completed.emit(result)
                else:
                    self.wipe_completed.emit({'status': 'cancelled', 'error': 'Operation cancelled by user'})
            else:
                # Process files one by one with progress updates
                successful = 0
                failed = 0
                cancelled = 0
                results = []
                
                for i, file_path in enumerate(self.file_paths):
                    if self._stop_requested:
                        cancelled = len(self.file_paths) - i
                        break
                        
                    self.progress_updated.emit(f"Processing {i+1}/{len(self.file_paths)}: {os.path.basename(file_path)}")
                    self.file_progress.emit(i+1, len(self.file_paths))
                    
                    try:
                        result = self.wiper.secure_delete_file(file_path, self.passes)
                        results.append(result)
                        if result['status'] == 'completed':
                            successful += 1
                        elif result['status'] == 'cancelled':
                            cancelled += 1
                        else:
                            failed += 1
                    except Exception as e:
                        failed += 1
                        results.append({'status': 'failed', 'error': str(e), 'file_path': file_path})
                
                batch_result = {
                    'batch_id': f"batch_{len(self.file_paths)}_{successful}",
                    'total_files': len(self.file_paths),
                    'successful': successful,
                    'failed': failed,
                    'cancelled': cancelled,
                    'results': results
                }
                self.wipe_completed.emit(batch_result)
                
        except Exception as e:
            error_result = {'status': 'failed', 'error': f"Thread error: {str(e)}"}
            self.wipe_completed.emit(error_result)

class FileSecureWipeGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.selected_files = []
        self.wiper = FileSecureWipe()
        self.wipe_thread = None
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("SecureWipe India - File-Level Secure Deletion (Optimized)")
        self.setGeometry(100, 100, 700, 550)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout()
        central_widget.setLayout(layout)
        
        # Header
        header_label = QLabel("Secure File Deletion with Metadata Clearing")
        header_label.setAlignment(Qt.AlignCenter)
        header_label.setStyleSheet("font-size: 20px; font-weight: bold; color: #2E8B57; margin: 15px;")
        layout.addWidget(header_label)
        
        # Description
        desc_label = QLabel("Optimized version - No freezing, faster processing")
        desc_label.setAlignment(Qt.AlignCenter)
        desc_label.setStyleSheet("font-size: 12px; color: #666; margin-bottom: 15px;")
        layout.addWidget(desc_label)
        
        # File selection section
        file_group = QGroupBox("Select Files to Securely Delete")
        file_layout = QVBoxLayout()
        
        # File list with context menu
        self.file_list = QListWidget()
        self.file_list.setMinimumHeight(150)
        self.file_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.file_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.file_list.customContextMenuRequested.connect(self.show_context_menu)
        file_layout.addWidget(self.file_list)
        
        # File selection buttons
        button_layout = QHBoxLayout()
        
        add_files_btn = QPushButton("Add Files")
        add_files_btn.clicked.connect(self.add_files)
        button_layout.addWidget(add_files_btn)
        
        add_folder_btn = QPushButton("Add Folder Contents")
        add_folder_btn.clicked.connect(self.add_folder)
        button_layout.addWidget(add_folder_btn)
        
        remove_selected_btn = QPushButton("Remove Selected")
        remove_selected_btn.clicked.connect(self.remove_selected_files)
        button_layout.addWidget(remove_selected_btn)
        
        clear_btn = QPushButton("Clear All")
        clear_btn.clicked.connect(self.clear_files)
        button_layout.addWidget(clear_btn)
        
        file_layout.addLayout(button_layout)
        file_group.setLayout(file_layout)
        layout.addWidget(file_group)
        
        # Wipe settings
        settings_group = QGroupBox("Deletion Settings")
        settings_layout = QHBoxLayout()
        
        settings_layout.addWidget(QLabel("Overwrite Passes:"))
        
        self.passes_spin = QSpinBox()
        self.passes_spin.setMinimum(1)
        self.passes_spin.setMaximum(10)  # Reduced max from 35 to 10 for performance
        self.passes_spin.setValue(3)
        self.passes_spin.setToolTip("Recommended: 3 passes for most cases, 7 for high security")
        settings_layout.addWidget(self.passes_spin)
        
        settings_layout.addWidget(QLabel("(3 passes recommended for balance)"))
        settings_layout.addStretch()
        
        settings_group.setLayout(settings_layout)
        layout.addWidget(settings_group)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Action buttons
        action_layout = QHBoxLayout()
        
        self.delete_button = QPushButton("🗑️ SECURE DELETE FILES")
        self.delete_button.setStyleSheet("""
            QPushButton {
                background-color: #DC143C;
                color: white;
                font-size: 16px;
                font-weight: bold;
                padding: 12px;
                border-radius: 8px;
                margin: 10px;
            }
            QPushButton:hover {
                background-color: #B22222;
            }
            QPushButton:disabled {
                background-color: #888;
            }
        """)
        self.delete_button.clicked.connect(self.start_secure_delete)
        self.delete_button.setEnabled(False)
        action_layout.addWidget(self.delete_button)
        
        self.cancel_button = QPushButton("❌ CANCEL")
        self.cancel_button.setStyleSheet("""
            QPushButton {
                background-color: #FF6347;
                color: white;
                font-size: 14px;
                font-weight: bold;
                padding: 10px;
                border-radius: 8px;
                margin: 10px;
            }
            QPushButton:hover {
                background-color: #FF4500;
            }
        """)
        self.cancel_button.clicked.connect(self.cancel_operation)
        self.cancel_button.setVisible(False)
        action_layout.addWidget(self.cancel_button)
        
        layout.addLayout(action_layout)
        
        # Progress and status
        self.progress_label = QLabel("Ready - Add files to begin secure deletion")
        self.progress_label.setStyleSheet("padding: 10px; background-color: #f0f0f0; border-radius: 5px;")
        layout.addWidget(self.progress_label)
        
        # Results area
        results_group = QGroupBox("Deletion Results")
        results_layout = QVBoxLayout()
        
        self.results_text = QTextEdit()
        self.results_text.setMaximumHeight(100)
        self.results_text.setReadOnly(True)
        results_layout.addWidget(self.results_text)
        
        # Certificate button
        self.cert_button = QPushButton("Generate Deletion Certificate")
        self.cert_button.setEnabled(False)
        self.cert_button.clicked.connect(self.generate_certificate)
        results_layout.addWidget(self.cert_button)
        
        results_group.setLayout(results_layout)
        layout.addWidget(results_group)
        
        # Menu bar
        self.create_menu_bar()
        
        # Status bar
        self.statusBar().showMessage("Ready")
    
    def create_menu_bar(self):
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu('File')
        
        exit_action = QAction('Exit', self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Help menu
        help_menu = menubar.addMenu('Help')
        
        about_action = QAction('About', self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def show_context_menu(self, position):
        """Show context menu for file list"""
        menu = QMenu()
        remove_action = menu.addAction("Remove Selected")
        remove_action.triggered.connect(self.remove_selected_files)
        menu.exec_(self.file_list.mapToGlobal(position))
    
    def add_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, 
            "Select Files to Securely Delete", 
            "",
            "All Files (*.*)"
        )
        
        for file_path in files:
            if file_path not in self.selected_files:
                self.selected_files.append(file_path)
                item = QListWidgetItem(f"📄 {os.path.basename(file_path)} ({file_path})")
                self.file_list.addItem(item)
        
        self.update_ui_state()
    
    def add_folder(self):
        folder_path = QFileDialog.getExistingDirectory(
            self, 
            "Select Folder to Add Files From"
        )
        
        if folder_path:
            try:
                files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) 
                        if os.path.isfile(os.path.join(folder_path, f))]
                
                added_count = 0
                for file_path in files:
                    if file_path not in self.selected_files:
                        self.selected_files.append(file_path)
                        item = QListWidgetItem(f"📄 {os.path.basename(file_path)} ({file_path})")
                        self.file_list.addItem(item)
                        added_count += 1
                
                self.progress_label.setText(f"Added {added_count} files from folder")
                self.update_ui_state()
                
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to read folder: {e}")
    
    def remove_selected_files(self):
        """Remove selected files from the list"""
        selected_items = self.file_list.selectedItems()
        if not selected_items:
            return
        
        for item in selected_items:
            row = self.file_list.row(item)
            self.file_list.takeItem(row)
            if row < len(self.selected_files):
                del self.selected_files[row]
        
        self.update_ui_state()
    
    def clear_files(self):
        self.selected_files.clear()
        self.file_list.clear()
        self.update_ui_state()
        self.progress_label.setText("File list cleared")
    
    def update_ui_state(self):
        has_files = len(self.selected_files) > 0
        self.delete_button.setEnabled(has_files)
        
        if has_files:
            self.statusBar().showMessage(f"{len(self.selected_files)} files selected")
        else:
            self.statusBar().showMessage("No files selected")
    
    def start_secure_delete(self):
        if not self.selected_files:
            return
        
        # Confirmation dialog
        file_list = "\n".join([f"• {os.path.basename(f)}" for f in self.selected_files[:10]])
        if len(self.selected_files) > 10:
            file_list += f"\n... and {len(self.selected_files) - 10} more files"
        
        reply = QMessageBox.question(
            self,
            "Confirm Secure Deletion",
            f"Are you sure you want to securely delete these files?\n\n"
            f"{file_list}\n\n"
            f"⚠️ THIS ACTION CANNOT BE UNDONE! ⚠️\n"
            f"Files will be permanently destroyed.\n\n"
            f"Overwrite passes: {self.passes_spin.value()}",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
        
        # Disable UI and show progress
        self.delete_button.setEnabled(False)
        self.cert_button.setEnabled(False)
        self.cancel_button.setVisible(True)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        
        # Start deletion thread
        self.wipe_thread = FileWipeThread(self.selected_files.copy(), self.passes_spin.value())
        self.wipe_thread.progress_updated.connect(self.update_progress)
        self.wipe_thread.wipe_completed.connect(self.deletion_completed)
        self.wipe_thread.file_progress.connect(self.update_file_progress)
        self.wipe_thread.single_file_progress.connect(self.update_single_file_progress)
        self.wipe_thread.start()
        
        self.progress_label.setText("Secure deletion in progress...")
    
    def cancel_operation(self):
        """Cancel the ongoing deletion operation"""
        if self.wipe_thread and self.wipe_thread.isRunning():
            self.wipe_thread.stop()
            self.progress_label.setText("Cancelling operation...")
            self.cancel_button.setEnabled(False)
    
    def update_progress(self, message):
        self.progress_label.setText(message)
    
    def update_file_progress(self, current, total):
        """Update progress bar for multiple files"""
        progress = int((current / total) * 100)
        self.progress_bar.setValue(progress)
    
    def update_single_file_progress(self, percentage):
        """Update progress bar for single file"""
        self.progress_bar.setValue(percentage)
    
    def deletion_completed(self, result):
        self.last_result = result
        
        # Re-enable UI and hide progress
        self.delete_button.setEnabled(True)
        self.cancel_button.setVisible(False)
        self.progress_bar.setVisible(False)
        
        if 'batch_id' in result:  # Multiple files
            successful = result.get('successful', 0)
            failed = result.get('failed', 0)
            cancelled = result.get('cancelled', 0)
            total = result['total_files']
            
            self.results_text.append(f"Batch deletion completed:")
            self.results_text.append(f"✅ Successful: {successful}/{total}")
            if failed > 0:
                self.results_text.append(f"❌ Failed: {failed}/{total}")
            if cancelled > 0:
                self.results_text.append(f"⚠️ Cancelled: {cancelled}/{total}")
            
            self.progress_label.setText(f"Completed: {successful} successful, {failed} failed, {cancelled} cancelled")
            
        else:  # Single file
            if result['status'] == 'completed':
                self.results_text.append(f"✅ File securely deleted: {os.path.basename(result['file_path'])}")
                self.results_text.append(f"   Steps completed: {len(result['steps_completed'])}")
                self.results_text.append(f"   Metadata cleared: {'Yes' if result['metadata_cleared'] else 'No'}")
                self.progress_label.setText("Secure deletion completed successfully")
            elif result['status'] == 'cancelled':
                self.results_text.append(f"⚠️ Deletion cancelled by user")
                self.progress_label.setText("Operation cancelled")
            else:
                self.results_text.append(f"❌ Deletion failed: {result.get('error', 'Unknown error')}")
                self.progress_label.setText("Secure deletion failed")
        
        # Enable certificate generation if successful
        if result.get('status') == 'completed' or result.get('successful', 0) > 0:
            self.cert_button.setEnabled(True)
        
        # Clear file list
        self.selected_files.clear()
        self.file_list.clear()
        self.update_ui_state()
    
    def generate_certificate(self):
        if not hasattr(self, 'last_result'):
            return
        
        try:
            if 'batch_id' in self.last_result:
                # Multiple files certificate
                cert_data = {
                    'certificate_type': 'batch_file_deletion',
                    'batch_id': self.last_result['batch_id'],
                    'timestamp': QDateTime.currentDateTime().toString(),
                    'summary': {
                        'total_files': self.last_result['total_files'],
                        'successful': self.last_result.get('successful', 0),
                        'failed': self.last_result.get('failed', 0),
                        'cancelled': self.last_result.get('cancelled', 0)
                    },
                    'individual_results': self.last_result['results']
                }
            else:
                # Single file certificate
                session_id = self.last_result['session_id']
                cert_data = self.wiper.generate_deletion_certificate(session_id)
            
            # Save certificate
            file_path, _ = QFileDialog.getSaveFileName(
                self,
                "Save Deletion Certificate",
                f"deletion_certificate_{QDateTime.currentDateTime().toString('yyyyMMdd_hhmmss')}.json",
                "JSON Files (*.json)"
            )
            
            if file_path:
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(cert_data, f, indent=2, ensure_ascii=False)
                
                QMessageBox.information(self, "Success", f"Certificate saved: {file_path}")
                self.results_text.append(f"📄 Certificate saved: {os.path.basename(file_path)}")
        
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to generate certificate: {e}")
    
    def show_about(self):
        QMessageBox.about(
            self,
            "About File Secure Wipe (Optimized)",
            "SecureWipe India - File-Level Secure Deletion\n\n"
            "Optimized Version - No Freezing Issues\n\n"
            "Improvements:\n"
            "• Faster processing with optimized algorithms\n"
            "• Proper thread cancellation support\n"
            "• Progress tracking for operations\n"
            "• Timeout protection for system calls\n"
            "• Better error handling\n\n"
            "Features:\n"
            "• Multi-pass overwriting\n"
            "• Metadata clearing\n"
            "• Filename obfuscation\n"
            "• Deletion certificates\n\n"
            "Version 2.0 (Optimized)"
        )
    
    def closeEvent(self, event):
        """Handle window close event"""
        if self.wipe_thread and self.wipe_thread.isRunning():
            reply = QMessageBox.question(
                self,
                "Operation in Progress",
                "A deletion operation is in progress. Do you want to cancel it and exit?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                self.wipe_thread.stop()
                self.wipe_thread.wait(2000)  # Wait up to 2 seconds
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("SecureWipe India - File Deletion (Optimized)")
    
    window = FileSecureWipeGUI()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()

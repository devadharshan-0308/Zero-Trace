"""
Quick Folder Photo Deletion
Processes all images in a folder quickly - no GUI hanging
"""

import os
import sys
import glob
import time

def delete_photos_in_folder(folder_path):
    """Delete all photos in a folder quickly"""
    
    # Common image extensions
    image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.gif', '*.bmp', '*.webp']
    
    all_photos = []
    for ext in image_extensions:
        pattern = os.path.join(folder_path, ext)
        all_photos.extend(glob.glob(pattern))
        # Also check uppercase
        pattern_upper = os.path.join(folder_path, ext.upper())
        all_photos.extend(glob.glob(pattern_upper))
    
    if not all_photos:
        print(f"No photos found in: {folder_path}")
        return
    
    print(f"Found {len(all_photos)} photos to delete:")
    for i, photo in enumerate(all_photos, 1):
        print(f"  {i}. {os.path.basename(photo)}")
    
    # Confirm deletion
    response = input(f"\nDelete all {len(all_photos)} photos? (yes/no): ").lower()
    if response not in ['yes', 'y']:
        print("Deletion cancelled.")
        return
    
    print("\nDeleting photos...")
    start_time = time.time()
    
    successful = 0
    failed = 0
    
    for i, photo_path in enumerate(all_photos, 1):
        try:
            print(f"Processing {i}/{len(all_photos)}: {os.path.basename(photo_path)}")
            
            # Quick secure overwrite
            file_size = os.path.getsize(photo_path)
            
            # Single pass overwrite with zeros (fast for images)
            with open(photo_path, 'r+b') as f:
                f.seek(0)
                f.write(b'\x00' * file_size)
                f.flush()
            
            # Rename to random name
            import random
            import string
            random_name = ''.join(random.choices(string.ascii_lowercase, k=10))
            temp_path = os.path.join(os.path.dirname(photo_path), random_name + '.tmp')
            os.rename(photo_path, temp_path)
            
            # Delete
            os.remove(temp_path)
            
            successful += 1
            print(f"  ✓ Deleted successfully")
            
        except Exception as e:
            failed += 1
            print(f"  ✗ Failed: {e}")
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"\n=== DELETION COMPLETE ===")
    print(f"Successful: {successful}")
    print(f"Failed: {failed}")
    print(f"Total time: {duration:.2f} seconds")
    print(f"Average per file: {duration/len(all_photos):.2f} seconds")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python delete_folder_photos.py <folder_path>")
        print("Example: python delete_folder_photos.py \"C:\\Users\\Photos\\WhatsApp\"")
        sys.exit(1)
    
    folder_path = sys.argv[1]
    
    if not os.path.exists(folder_path):
        print(f"Folder not found: {folder_path}")
        sys.exit(1)
    
    if not os.path.isdir(folder_path):
        print(f"Not a folder: {folder_path}")
        sys.exit(1)
    
    delete_photos_in_folder(folder_path)

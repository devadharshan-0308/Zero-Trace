"""
Gamification Integration for Zero Trace GUI
This script demonstrates how to integrate the gamification system
"""
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QTabWidget
from zero_trace_gui import ZeroTraceGUI
from impact_dashboard import ImpactDashboard
from gamification_engine import GamificationEngine
from shareable_certificate import ShareableCertificate

class GamifiedZeroTrace(QMainWindow):
    def __init__(self):
        super().__init__()
        self.user_id = "default_user"
        self.gamification = GamificationEngine()
        self.certificate_generator = ShareableCertificate()
        self.init_ui()
        
    def init_ui(self):
        """Initialize the gamified UI with tabs"""
        self.setWindowTitle("Zero Trace - Gamified E-Waste Data Sanitization")
        self.setGeometry(100, 100, 1000, 800)
        
        # Create central widget with tabs
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Main Zero Trace tab
        self.zero_trace_gui = ZeroTraceGUI()
        self.tab_widget.addTab(self.zero_trace_gui, "🔥 Secure Wipe")
        
        # Impact Dashboard tab
        self.impact_dashboard = ImpactDashboard(self.user_id)
        self.tab_widget.addTab(self.impact_dashboard, "🌍 Impact Dashboard")
        
        layout.addWidget(self.tab_widget)
        
        # Connect wipe completion to gamification
        if hasattr(self.zero_trace_gui, 'wipe_completed'):
            # This would need to be properly connected in the actual integration
            pass
            
    def record_wipe_achievement(self, result):
        """Record wipe operation for gamification"""
        try:
            device_count = 1 if result.get('type') == 'device' else 0
            file_count = result.get('files_deleted', 0) if result.get('type') == 'device' else result.get('successful', 0)
            method = result.get('method', 'unknown')
            
            # Record in gamification system
            gamification_result = self.gamification.record_wipe_session(
                self.user_id, device_count, file_count, method
            )
            
            # Show achievements if any
            if gamification_result['new_achievements']:
                self.show_achievements(gamification_result['new_achievements'])
                
            # Update dashboard
            self.impact_dashboard.load_data()
            
        except Exception as e:
            print(f"Error recording achievement: {e}")
            
    def show_achievements(self, achievements):
        """Show achievement notifications"""
        from PyQt5.QtWidgets import QMessageBox
        
        for achievement in achievements:
            QMessageBox.information(
                self, 
                "🏆 Achievement Unlocked!", 
                f"{achievement['icon']} {achievement['name']}\n\n"
                f"{achievement['description']}\n\n"
                f"Points earned: +{achievement['points']}"
            )
            
    def generate_shareable_content(self):
        """Generate content for social sharing"""
        content = self.certificate_generator.generate_shareable_content(self.user_id)
        
        from PyQt5.QtWidgets import QMessageBox
        QMessageBox.information(
            self,
            "📱 Share Your Impact",
            f"Share this message:\n\n{content['message']}\n\n{content['hashtags']}\n\n"
            f"Stats:\n"
            f"• Devices wiped: {content['stats']['devices_wiped']}\n"
            f"• CO₂ saved: {content['stats']['co2_saved']:.1f}kg\n"
            f"• Achievements: {content['stats']['achievements_count']}"
        )

def main():
    """Main entry point for gamified Zero Trace"""
    app = QApplication(sys.argv)
    app.setApplicationName("Zero Trace - Gamified Edition")
    app.setStyle('Fusion')
    
    window = GamifiedZeroTrace()
    window.show()
    
    return app.exec_()

if __name__ == "__main__":
    sys.exit(main())

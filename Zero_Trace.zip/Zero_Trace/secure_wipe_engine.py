"""
Secure Data Wiping Engine - NIST SP 800-88 Compliant
Addresses India's e-waste crisis by providing secure, verifiable data erasure
"""

import os
import sys
import time
import hashlib
import platform
import subprocess
import psutil
from typing import List, Dict, Optional, Tuple
from enum import Enum
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization
import json
import uuid
from datetime import datetime

class StorageType(Enum):
    HDD = "HDD"
    SSD = "SSD" 
    FLASH = "FLASH"
    UNKNOWN = "UNKNOWN"

class WipeMethod(Enum):
    NIST_CLEAR = "NIST_Clear"
    NIST_PURGE = "NIST_Purge"
    DOD_3PASS = "DoD_3Pass"
    DOD_7PASS = "DoD_7Pass"
    GUTMANN = "Gutmann_35Pass"

class WipeStatus(Enum):
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    VERIFIED = "verified"

class SecureWipeEngine:
    """
    Core engine for secure data wiping following NIST SP 800-88 guidelines
    """
    
    def __init__(self):
        self.platform = platform.system().lower()
        self.wipe_sessions = {}
        self.verification_keys = self._generate_verification_keys()
        
    def _generate_verification_keys(self) -> Tuple[bytes, bytes]:
        """Generate RSA key pair for digital signatures"""
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_key = private_key.public_key()
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return private_pem, public_pem
    
    def detect_storage_devices(self) -> List[Dict]:
        """Detect all storage devices on the system"""
        devices = []
        
        try:
            # Get disk partitions
            partitions = psutil.disk_partitions()
            
            for partition in partitions:
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    device_info = {
                        'device': partition.device,
                        'mountpoint': partition.mountpoint,
                        'fstype': partition.fstype,
                        'total_size': usage.total,
                        'used_size': usage.used,
                        'free_size': usage.free,
                        'storage_type': self._detect_storage_type(partition.device),
                        'serial_number': self._get_device_serial(partition.device),
                        'model': self._get_device_model(partition.device)
                    }
                    devices.append(device_info)
                except PermissionError:
                    continue
                    
        except Exception as e:
            print(f"Error detecting devices: {e}")
            
        return devices
    
    def _detect_storage_type(self, device_path: str) -> StorageType:
        """Detect if device is HDD, SSD, or Flash storage"""
        try:
            if self.platform == "windows":
                # Method 1: Check using wmic diskdrive
                try:
                    cmd = 'wmic diskdrive get Model,MediaType,InterfaceType /format:csv'
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
                    
                    if result.stdout:
                        output_upper = result.stdout.upper()
                        # Check for SSD indicators
                        if any(indicator in output_upper for indicator in ['SSD', 'SOLID STATE', 'NVME', 'M.2']):
                            return StorageType.SSD
                        elif any(indicator in output_upper for indicator in ['USB', 'FLASH', 'REMOVABLE']):
                            return StorageType.FLASH
                except Exception:
                    pass
                
                # Method 2: Check using PowerShell (more reliable for modern SSDs)
                try:
                    ps_cmd = 'powershell "Get-PhysicalDisk | Select-Object MediaType,BusType,Model | ConvertTo-Csv -NoTypeInformation"'
                    result = subprocess.run(ps_cmd, shell=True, capture_output=True, text=True, timeout=10)
                    
                    if result.stdout:
                        output_upper = result.stdout.upper()
                        if 'SSD' in output_upper or 'SOLID STATE' in output_upper:
                            return StorageType.SSD
                        elif 'USB' in output_upper or 'REMOVABLE' in output_upper:
                            return StorageType.FLASH
                except Exception:
                    pass
                
                # Method 3: Check filesystem characteristics (fallback)
                try:
                    # Modern Windows systems with SSDs often have specific characteristics
                    cmd = f'fsutil fsinfo drives'
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=5)
                    
                    # If we can't determine, assume SSD for modern systems (most common now)
                    # This is a reasonable assumption for systems running this application
                    return StorageType.SSD
                    
                except Exception:
                    pass
                    
            elif self.platform == "linux":
                # Check if device is rotational (0 = SSD, 1 = HDD)
                device_name = device_path.split('/')[-1].rstrip('0123456789')
                rotational_path = f"/sys/block/{device_name}/queue/rotational"
                
                if os.path.exists(rotational_path):
                    with open(rotational_path, 'r') as f:
                        if f.read().strip() == '0':
                            return StorageType.SSD
                        else:
                            return StorageType.HDD
                            
        except Exception:
            pass
            
        # Default to SSD for modern systems if detection fails
        return StorageType.SSD
    
    def _get_device_serial(self, device_path: str) -> str:
        """Get device serial number"""
        try:
            if self.platform == "windows":
                cmd = f'wmic diskdrive where "DeviceID=\\"{device_path.replace(":", "").replace("\\", "")}\\"" get SerialNumber /format:csv'
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    return lines[1].split(',')[-1].strip()
                    
            elif self.platform == "linux":
                device_name = device_path.split('/')[-1].rstrip('0123456789')
                cmd = f"udevadm info --query=all --name=/dev/{device_name} | grep ID_SERIAL_SHORT"
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                if result.stdout:
                    return result.stdout.split('=')[1].strip()
                    
        except Exception:
            pass
            
        return "Unknown"
    
    def _get_device_model(self, device_path: str) -> str:
        """Get device model"""
        try:
            if self.platform == "windows":
                cmd = f'wmic diskdrive where "DeviceID=\\"{device_path.replace(":", "").replace("\\", "")}\\"" get Model /format:csv'
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    return lines[1].split(',')[-1].strip()
                    
            elif self.platform == "linux":
                device_name = device_path.split('/')[-1].rstrip('0123456789')
                cmd = f"udevadm info --query=all --name=/dev/{device_name} | grep ID_MODEL"
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                if result.stdout:
                    return result.stdout.split('=')[1].strip()
                    
        except Exception:
            pass
            
        return "Unknown"
    
    def secure_wipe_device(self, device_path: str, wipe_method: WipeMethod, 
                          progress_callback=None) -> Dict:
        """
        Perform secure wipe on entire device
        """
        session_id = str(uuid.uuid4())
        start_time = datetime.now()
        
        wipe_session = {
            'session_id': session_id,
            'device_path': device_path,
            'wipe_method': wipe_method.value,
            'start_time': start_time.isoformat(),
            'status': WipeStatus.IN_PROGRESS.value,
            'progress': 0,
            'verification_hash': None,
            'certificate_generated': False
        }
        
        self.wipe_sessions[session_id] = wipe_session
        
        try:
            # Get device info
            device_info = self._get_device_info(device_path)
            storage_type = device_info.get('storage_type', StorageType.UNKNOWN)
            
            # Choose appropriate wipe pattern based on storage type and method
            if storage_type == StorageType.SSD:
                success = self._wipe_ssd(device_path, wipe_method, progress_callback)
            elif storage_type == StorageType.HDD:
                success = self._wipe_hdd(device_path, wipe_method, progress_callback)
            else:
                success = self._wipe_generic(device_path, wipe_method, progress_callback)
            
            if success:
                wipe_session['status'] = WipeStatus.COMPLETED.value
                wipe_session['end_time'] = datetime.now().isoformat()
                wipe_session['verification_hash'] = self._generate_verification_hash(device_path)
                
                # Generate certificate
                certificate = self._generate_wipe_certificate(wipe_session, device_info)
                wipe_session['certificate'] = certificate
                wipe_session['certificate_generated'] = True
                
            else:
                wipe_session['status'] = WipeStatus.FAILED.value
                
        except Exception as e:
            wipe_session['status'] = WipeStatus.FAILED.value
            wipe_session['error'] = str(e)
            
        return wipe_session
    
    def _wipe_ssd(self, device_path: str, wipe_method: WipeMethod, progress_callback=None) -> bool:
        """SSD-specific secure wipe using ATA Secure Erase if available"""
        try:
            # Try ATA Secure Erase first (most effective for SSDs)
            if self._ata_secure_erase(device_path):
                if progress_callback:
                    progress_callback(100)
                return True
            
            # Fallback to cryptographic erase
            return self._crypto_erase_ssd(device_path, progress_callback)
            
        except Exception as e:
            print(f"SSD wipe failed: {e}")
            return False
    
    def _wipe_hdd(self, device_path: str, wipe_method: WipeMethod, progress_callback=None) -> bool:
        """HDD-specific secure wipe with multiple passes"""
        try:
            patterns = self._get_wipe_patterns(wipe_method)
            device_size = self._get_device_size(device_path)
            
            if device_size == 0:
                return False
            
            total_passes = len(patterns)
            
            for pass_num, pattern in enumerate(patterns):
                if not self._write_pattern_to_device(device_path, pattern, device_size):
                    return False
                
                if progress_callback:
                    progress = int(((pass_num + 1) / total_passes) * 100)
                    progress_callback(progress)
            
            return True
            
        except Exception as e:
            print(f"HDD wipe failed: {e}")
            return False
    
    def _wipe_generic(self, device_path: str, wipe_method: WipeMethod, progress_callback=None) -> bool:
        """Generic wipe for unknown storage types"""
        return self._wipe_hdd(device_path, wipe_method, progress_callback)
    
    def _ata_secure_erase(self, device_path: str) -> bool:
        """Attempt ATA Secure Erase command"""
        try:
            if self.platform == "linux":
                # Check if secure erase is supported
                device_name = device_path.split('/')[-1]
                cmd = f"hdparm -I /dev/{device_name} | grep -i 'erase'"
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                
                if "supported" in result.stdout.lower():
                    # Set security password
                    subprocess.run(f"hdparm --user-master u --security-set-pass p /dev/{device_name}", 
                                 shell=True, check=True)
                    
                    # Execute secure erase
                    subprocess.run(f"hdparm --user-master u --security-erase p /dev/{device_name}", 
                                 shell=True, check=True)
                    return True
                    
            elif self.platform == "windows":
                # Use Windows format command with secure option
                drive_letter = device_path[0]
                cmd = f"format {drive_letter}: /fs:NTFS /p:3 /q /y"
                result = subprocess.run(cmd, shell=True, capture_output=True)
                return result.returncode == 0
                
        except Exception:
            pass
            
        return False
    
    def _crypto_erase_ssd(self, device_path: str, progress_callback=None) -> bool:
        """Cryptographic erase for SSDs"""
        try:
            # Generate random encryption key
            key = os.urandom(32)
            
            # Encrypt entire device with random key
            device_size = self._get_device_size(device_path)
            chunk_size = 1024 * 1024  # 1MB chunks
            
            with open(device_path, 'r+b') as device:
                bytes_written = 0
                
                while bytes_written < device_size:
                    remaining = min(chunk_size, device_size - bytes_written)
                    encrypted_data = os.urandom(remaining)
                    
                    device.write(encrypted_data)
                    bytes_written += remaining
                    
                    if progress_callback:
                        progress = int((bytes_written / device_size) * 100)
                        progress_callback(progress)
            
            # Destroy the key
            key = b'\x00' * len(key)
            del key
            
            return True
            
        except Exception as e:
            print(f"Crypto erase failed: {e}")
            return False
    
    def _get_wipe_patterns(self, wipe_method: WipeMethod) -> List[bytes]:
        """Get wipe patterns based on method"""
        if wipe_method == WipeMethod.NIST_CLEAR:
            return [b'\x00', b'\xFF', os.urandom(1)]
            
        elif wipe_method == WipeMethod.DOD_3PASS:
            return [b'\x00', b'\xFF', os.urandom(1)]
            
        elif wipe_method == WipeMethod.DOD_7PASS:
            return [
                b'\x00', b'\xFF', b'\x00', b'\xFF',
                os.urandom(1), os.urandom(1), b'\x00'
            ]
            
        elif wipe_method == WipeMethod.GUTMANN:
            # Simplified Gutmann patterns (first 10 of 35)
            patterns = []
            for i in range(10):
                patterns.append(os.urandom(1))
            return patterns
            
        else:  # Default to NIST Clear
            return [b'\x00', b'\xFF', os.urandom(1)]
    
    def _write_pattern_to_device(self, device_path: str, pattern: bytes, device_size: int) -> bool:
        """Write pattern to entire device"""
        try:
            chunk_size = 1024 * 1024  # 1MB chunks
            
            with open(device_path, 'r+b') as device:
                bytes_written = 0
                
                while bytes_written < device_size:
                    remaining = min(chunk_size, device_size - bytes_written)
                    
                    # Repeat pattern to fill chunk
                    chunk_data = (pattern * (remaining // len(pattern) + 1))[:remaining]
                    
                    device.write(chunk_data)
                    device.flush()
                    os.fsync(device.fileno())
                    
                    bytes_written += remaining
            
            return True
            
        except Exception as e:
            print(f"Pattern write failed: {e}")
            return False
    
    def _get_device_size(self, device_path: str) -> int:
        """Get device size in bytes"""
        try:
            if self.platform == "linux":
                with open(device_path, 'rb') as device:
                    device.seek(0, 2)  # Seek to end
                    return device.tell()
                    
            elif self.platform == "windows":
                # Use wmic to get disk size
                drive_letter = device_path[0]
                cmd = f'wmic logicaldisk where "DeviceID=\\"{drive_letter}:\\"" get Size /format:csv'
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    return int(lines[1].split(',')[-1].strip())
                    
        except Exception:
            pass
            
        return 0
    
    def _get_device_info(self, device_path: str) -> Dict:
        """Get comprehensive device information"""
        devices = self.detect_storage_devices()
        for device in devices:
            if device['device'] == device_path or device['mountpoint'] == device_path:
                return device
        
        return {'storage_type': StorageType.UNKNOWN}
    
    def _generate_verification_hash(self, device_path: str) -> str:
        """Generate verification hash of wiped device"""
        try:
            hasher = hashlib.sha256()
            chunk_size = 1024 * 1024  # 1MB chunks
            
            with open(device_path, 'rb') as device:
                # Sample first 100MB for verification
                bytes_read = 0
                max_bytes = 100 * 1024 * 1024
                
                while bytes_read < max_bytes:
                    chunk = device.read(min(chunk_size, max_bytes - bytes_read))
                    if not chunk:
                        break
                    hasher.update(chunk)
                    bytes_read += len(chunk)
            
            return hasher.hexdigest()
            
        except Exception:
            return "verification_failed"
    
    def _generate_wipe_certificate(self, wipe_session: Dict, device_info: Dict) -> Dict:
        """Generate tamper-proof wipe certificate"""
        certificate = {
            'certificate_id': str(uuid.uuid4()),
            'session_id': wipe_session['session_id'],
            'timestamp': datetime.now().isoformat(),
            'device_info': {
                'device_path': device_info.get('device', 'Unknown'),
                'serial_number': device_info.get('serial_number', 'Unknown'),
                'model': device_info.get('model', 'Unknown'),
                'storage_type': device_info.get('storage_type', StorageType.UNKNOWN).value,
                'total_size': device_info.get('total_size', 0)
            },
            'wipe_details': {
                'method': wipe_session['wipe_method'],
                'start_time': wipe_session['start_time'],
                'end_time': wipe_session.get('end_time'),
                'status': wipe_session['status'],
                'verification_hash': wipe_session['verification_hash']
            },
            'compliance': {
                'standard': 'NIST SP 800-88',
                'classification': 'Clear/Purge',
                'verification_method': 'Cryptographic Hash'
            },
            'issuer': {
                'organization': 'SecureWipe India',
                'platform': self.platform,
                'version': '1.0.0'
            }
        }
        
        # Generate digital signature
        certificate_json = json.dumps(certificate, sort_keys=True)
        signature = self._sign_certificate(certificate_json.encode())
        certificate['digital_signature'] = signature.hex()
        
        return certificate
    
    def _sign_certificate(self, data: bytes) -> bytes:
        """Sign certificate with private key"""
        try:
            private_key = serialization.load_pem_private_key(
                self.verification_keys[0], password=None
            )
            
            signature = private_key.sign(
                data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            return signature
            
        except Exception:
            return b"signature_failed"
    
    def verify_certificate(self, certificate: Dict) -> bool:
        """Verify certificate digital signature"""
        try:
            # Extract signature
            signature_hex = certificate.pop('digital_signature', '')
            signature = bytes.fromhex(signature_hex)
            
            # Recreate certificate data
            certificate_json = json.dumps(certificate, sort_keys=True)
            
            # Verify signature
            public_key = serialization.load_pem_public_key(self.verification_keys[1])
            
            public_key.verify(
                signature,
                certificate_json.encode(),
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            # Restore signature to certificate
            certificate['digital_signature'] = signature_hex
            
            return True
            
        except Exception:
            return False
    
    def get_wipe_session(self, session_id: str) -> Optional[Dict]:
        """Get wipe session details"""
        return self.wipe_sessions.get(session_id)
    
    def list_wipe_sessions(self) -> List[Dict]:
        """List all wipe sessions"""
        return list(self.wipe_sessions.values())

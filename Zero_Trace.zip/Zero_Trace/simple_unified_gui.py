"""
Simple Unified SecureWipe GUI - Complete Working Version
Single interface for both file-level and partition-level secure deletion
"""

import sys
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

class SimpleUnifiedGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.selected_files = []
        self.selected_partition = None
        self.current_mode = 'files'
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("SecureWipe India - Unified Data Destruction")
        self.setGeometry(100, 100, 800, 600)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout()
        central_widget.setLayout(layout)
        
        # Header
        header = QLabel("🛡️ SecureWipe India - Unified System")
        header.setAlignment(Qt.AlignCenter)
        header.setStyleSheet("font-size: 24px; font-weight: bold; color: #2E8B57; padding: 15px;")
        layout.addWidget(header)
        
        # Tab widget
        self.tab_widget = QTabWidget()
        
        # File deletion tab
        file_tab = QWidget()
        file_layout = QVBoxLayout()
        
        file_layout.addWidget(QLabel("Select files to securely delete:"))
        
        self.file_list = QListWidget()
        self.file_list.setMinimumHeight(200)
        file_layout.addWidget(self.file_list)
        
        # File buttons
        file_buttons = QHBoxLayout()
        
        add_files_btn = QPushButton("Add Files")
        add_files_btn.clicked.connect(self.add_files)
        file_buttons.addWidget(add_files_btn)
        
        add_folder_btn = QPushButton("Add Folder")
        add_folder_btn.clicked.connect(self.add_folder)
        file_buttons.addWidget(add_folder_btn)
        
        clear_files_btn = QPushButton("Clear All")
        clear_files_btn.clicked.connect(self.clear_files)
        file_buttons.addWidget(clear_files_btn)
        
        file_layout.addLayout(file_buttons)
        
        self.file_count_label = QLabel("No files selected")
        file_layout.addWidget(self.file_count_label)
        
        file_tab.setLayout(file_layout)
        self.tab_widget.addTab(file_tab, "📄 File Deletion")
        
        # Partition tab
        partition_tab = QWidget()
        partition_layout = QVBoxLayout()
        
        # Warning
        warning = QLabel("⚠️ WARNING: Partition wiping will destroy ALL data permanently!")
        warning.setStyleSheet("background: #FFF3CD; border: 1px solid #FFC107; padding: 10px; border-radius: 5px;")
        warning.setWordWrap(True)
        partition_layout.addWidget(warning)
        
        partition_layout.addWidget(QLabel("Available drives:"))
        
        self.drive_list = QListWidget()
        self.drive_list.setMinimumHeight(200)
        self.drive_list.itemClicked.connect(self.on_drive_selected)
        partition_layout.addWidget(self.drive_list)
        
        refresh_btn = QPushButton("🔄 Refresh Drives")
        refresh_btn.clicked.connect(self.refresh_drives)
        partition_layout.addWidget(refresh_btn)
        
        self.drive_info_label = QLabel("Select a drive to view details")
        self.drive_info_label.setStyleSheet("padding: 10px; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 5px;")
        partition_layout.addWidget(self.drive_info_label)
        
        partition_tab.setLayout(partition_layout)
        self.tab_widget.addTab(partition_tab, "💾 Partition Wiping")
        
        # Connect tab change
        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        
        layout.addWidget(self.tab_widget)
        
        # Controls
        controls_group = QGroupBox("Wipe Settings")
        controls_layout = QHBoxLayout()
        
        controls_layout.addWidget(QLabel("Overwrite Passes:"))
        
        self.passes_spin = QSpinBox()
        self.passes_spin.setMinimum(1)
        self.passes_spin.setMaximum(7)
        self.passes_spin.setValue(3)
        controls_layout.addWidget(self.passes_spin)
        
        controls_layout.addStretch()
        
        self.wipe_button = QPushButton("🔥 START SECURE WIPE")
        self.wipe_button.setStyleSheet("""
            QPushButton {
                background: #DC143C;
                color: white;
                font-size: 16px;
                font-weight: bold;
                padding: 12px 30px;
                border-radius: 8px;
            }
            QPushButton:hover {
                background: #B22222;
            }
            QPushButton:disabled {
                background: #888;
            }
        """)
        self.wipe_button.clicked.connect(self.start_wipe)
        self.wipe_button.setEnabled(False)
        controls_layout.addWidget(self.wipe_button)
        
        controls_group.setLayout(controls_layout)
        layout.addWidget(controls_group)
        
        # Status
        self.status_label = QLabel("Ready - Select files or partition to wipe")
        self.status_label.setStyleSheet("padding: 10px; background: #f0f0f0; border-radius: 5px;")
        layout.addWidget(self.status_label)
        
        # Results
        results_group = QGroupBox("Results")
        results_layout = QVBoxLayout()
        
        self.results_text = QTextEdit()
        self.results_text.setMaximumHeight(100)
        self.results_text.setReadOnly(True)
        results_layout.addWidget(self.results_text)
        
        results_group.setLayout(results_layout)
        layout.addWidget(results_group)
        
        # Initialize
        self.refresh_drives()
        self.update_ui_state()
    
    def on_tab_changed(self, index):
        """Handle tab change"""
        self.current_mode = 'files' if index == 0 else 'partition'
        self.update_ui_state()
    
    def add_files(self):
        """Add files to the deletion list"""
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "Select Files to Securely Delete",
            "",
            "All Files (*.*)"
        )
        
        for file_path in files:
            if file_path not in self.selected_files:
                self.selected_files.append(file_path)
                item = QListWidgetItem(f"📄 {os.path.basename(file_path)}")
                item.setToolTip(file_path)
                self.file_list.addItem(item)
        
        self.update_file_count()
        self.update_ui_state()
    
    def add_folder(self):
        """Add all files from a folder"""
        folder_path = QFileDialog.getExistingDirectory(
            self,
            "Select Folder to Add Files From"
        )
        
        if folder_path:
            try:
                added_count = 0
                for root, dirs, files in os.walk(folder_path):
                    for filename in files:
                        file_path = os.path.join(root, filename)
                        if file_path not in self.selected_files:
                            self.selected_files.append(file_path)
                            item = QListWidgetItem(f"📄 {filename}")
                            item.setToolTip(file_path)
                            self.file_list.addItem(item)
                            added_count += 1
                
                self.status_label.setText(f"Added {added_count} files from folder")
                self.update_file_count()
                self.update_ui_state()
                
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to read folder: {e}")
    
    def clear_files(self):
        """Clear all files from the list"""
        self.selected_files.clear()
        self.file_list.clear()
        self.update_file_count()
        self.update_ui_state()
    
    def update_file_count(self):
        """Update file count label"""
        count = len(self.selected_files)
        if count == 0:
            self.file_count_label.setText("No files selected")
        elif count == 1:
            self.file_count_label.setText("1 file selected")
        else:
            self.file_count_label.setText(f"{count} files selected")
    
    def refresh_drives(self):
        """Refresh the list of available drives"""
        self.drive_list.clear()
        
        try:
            import psutil
            partitions = psutil.disk_partitions()
            
            for partition in partitions:
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    total_gb = usage.total / (1024**3)
                    
                    item_text = f"{partition.device} - {partition.fstype} ({total_gb:.1f} GB)"
                    item = QListWidgetItem(item_text)
                    
                    # Store partition info
                    item.setData(Qt.UserRole, {
                        'path': partition.mountpoint,
                        'device': partition.device,
                        'fstype': partition.fstype,
                        'total_size': usage.total,
                        'used_size': usage.used,
                        'free_size': usage.free
                    })
                    
                    self.drive_list.addItem(item)
                except:
                    continue
                    
        except ImportError:
            # Fallback for Windows without psutil
            import string
            for letter in string.ascii_uppercase:
                drive_path = f"{letter}:\\"
                if os.path.exists(drive_path):
                    try:
                        item = QListWidgetItem(f"{letter}: - Local Drive")
                        item.setData(Qt.UserRole, {'path': drive_path})
                        self.drive_list.addItem(item)
                    except:
                        continue
    
    def on_drive_selected(self, item):
        """Handle drive selection"""
        drive_data = item.data(Qt.UserRole)
        self.selected_partition = drive_data['path']
        
        # Update drive info
        if 'total_size' in drive_data:
            total_gb = drive_data['total_size'] / (1024**3)
            used_gb = drive_data['used_size'] / (1024**3)
            free_gb = drive_data['free_size'] / (1024**3)
            
            info = f"<b>Selected Drive:</b> {drive_data['path']}<br>"
            info += f"<b>Filesystem:</b> {drive_data.get('fstype', 'Unknown')}<br>"
            info += f"<b>Total Size:</b> {total_gb:.1f} GB<br>"
            info += f"<b>Used Space:</b> {used_gb:.1f} GB<br>"
            info += f"<b>Free Space:</b> {free_gb:.1f} GB"
        else:
            info = f"<b>Selected Drive:</b> {drive_data['path']}"
        
        self.drive_info_label.setText(info)
        self.update_ui_state()
    
    def update_ui_state(self):
        """Update UI state based on current selections"""
        if self.current_mode == 'files':
            has_selection = len(self.selected_files) > 0
        else:
            has_selection = self.selected_partition is not None
        
        self.wipe_button.setEnabled(has_selection)
        
        if has_selection:
            if self.current_mode == 'files':
                self.status_label.setText(f"{len(self.selected_files)} files selected for deletion")
            else:
                self.status_label.setText(f"Partition {self.selected_partition} selected for wiping")
        else:
            self.status_label.setText("Ready - Select files or partition to wipe")
    
    def start_wipe(self):
        """Start the wipe operation"""
        if self.current_mode == 'files':
            if not self.selected_files:
                return
            
            # Confirmation dialog for files
            file_list = "\n".join([f"• {os.path.basename(f)}" for f in self.selected_files[:10]])
            if len(self.selected_files) > 10:
                file_list += f"\n... and {len(self.selected_files) - 10} more files"
            
            message = f"Are you sure you want to securely delete these files?\n\n{file_list}"
            
        else:
            if not self.selected_partition:
                return
            
            # Extra confirmation for partition wiping
            message = f"⚠️ CRITICAL WARNING ⚠️\n\n"
            message += f"You are about to COMPLETELY WIPE the partition:\n"
            message += f"{self.selected_partition}\n\n"
            message += f"ALL DATA WILL BE PERMANENTLY DESTROYED!\n"
            message += f"Are you ABSOLUTELY SURE you want to continue?"
        
        # Show confirmation dialog
        reply = QMessageBox.critical(
            self,
            "Confirm Secure Wipe",
            message + f"\n\nOverwrite passes: {self.passes_spin.value()}",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply != QMessageBox.Yes:
            return
        
        # For now, just show a message (you can integrate the actual wiping later)
        if self.current_mode == 'files':
            self.results_text.append(f"✅ Would delete {len(self.selected_files)} files with {self.passes_spin.value()} passes")
            self.results_text.append("(This is a demo - no actual deletion performed)")
            self.selected_files.clear()
            self.file_list.clear()
            self.update_file_count()
        else:
            self.results_text.append(f"✅ Would wipe partition {self.selected_partition} with {self.passes_spin.value()} passes")
            self.results_text.append("(This is a demo - no actual wiping performed)")
            self.selected_partition = None
            self.drive_info_label.setText("Select a drive to view details")
        
        self.update_ui_state()

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("SecureWipe India - Simple Unified")
    
    window = SimpleUnifiedGUI()
    window.show()
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()

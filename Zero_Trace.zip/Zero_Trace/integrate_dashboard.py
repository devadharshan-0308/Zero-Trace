"""
Simple Integration Script for Adding Professional Dashboard to main_fixed.py
This script modifies your existing main_fixed.py to include the environmental impact dashboard
"""

import os
import shutil
from datetime import datetime

def backup_main_fixed():
    """Create a backup of the original main_fixed.py"""
    if os.path.exists('main_fixed.py'):
        backup_name = f'main_fixed_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.py'
        shutil.copy2('main_fixed.py', backup_name)
        print(f"✅ Backup created: {backup_name}")
        return True
    return False

def create_enhanced_main():
    """Create enhanced main_fixed.py with dashboard integration"""
    
    enhanced_main_content = '''"""
Main Entry Point for SecureWipe India - Zero Trace Edition with Professional Dashboard
All Algorithms: NIST, DoD, Gutmann | Certificate Generation | Environmental Impact Tracking
"""

import sys
import os
from PyQt5.QtWidgets import QApplication, QMessageBox, QPushButton

def add_dashboard_to_gui(window):
    """Add professional environmental impact dashboard to the GUI"""
    try:
        from professional_gamification import ProfessionalImpactDashboard
        from gamification_engine import GamificationEngine
        
        # Initialize gamification system
        gamification = GamificationEngine()
        dashboard = None
        
        def show_dashboard():
            nonlocal dashboard
            try:
                if not dashboard:
                    dashboard = ProfessionalImpactDashboard("default_user", window)
                dashboard.show()
                dashboard.raise_()
                dashboard.activateWindow()
            except Exception as e:
                QMessageBox.critical(window, "Dashboard Error", 
                                   f"Failed to open dashboard:\\n{str(e)}")
        
        def track_wipe_operation(result):
            """Track wipe operations for environmental impact"""
            try:
                if result.get('status') == 'completed':
                    device_count = 1 if result.get('type') == 'device' else 0
                    file_count = result.get('files_deleted', 0) if result.get('type') == 'device' else result.get('successful', 0)
                    method = result.get('method', 'Unknown')
                    
                    # Record in gamification system
                    gamification_result = gamification.record_wipe_session(
                        user_id="default_user",
                        device_count=device_count,
                        file_count=file_count,
                        method=method
                    )
                    
                    # Show achievements if any
                    if gamification_result.get('new_achievements'):
                        for achievement in gamification_result['new_achievements']:
                            QMessageBox.information(
                                window,
                                "🏆 Achievement Unlocked!",
                                f"{achievement['icon']} {achievement['name']}\\n\\n"
                                f"{achievement['description']}\\n\\n"
                                f"Sustainability Points: +{achievement['points']}"
                            )
                    
                    # Update dashboard if open
                    if dashboard:
                        dashboard.load_data()
                        
            except Exception as e:
                print(f"⚠️ Failed to track wipe: {e}")
        
        # Create professional dashboard button
        dashboard_btn = QPushButton("🌍 Environmental Impact Dashboard")
        dashboard_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #28a745, stop:1 #20c997);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 20px;
                font-weight: bold;
                font-size: 13px;
                margin: 5px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #20c997, stop:1 #17a2b8);
            }
            QPushButton:pressed {
                background: #17a2b8;
            }
        """)
        dashboard_btn.clicked.connect(show_dashboard)
        
        # Add button to layout
        if hasattr(window, 'centralWidget'):
            central_widget = window.centralWidget()
            if central_widget and hasattr(central_widget, 'layout'):
                layout = central_widget.layout()
                if layout:
                    # Insert before the last widget (usually status bar)
                    layout.insertWidget(layout.count() - 1, dashboard_btn)
        
        # Hook into wipe completion
        if hasattr(window, 'wipe_completed'):
            original_wipe_completed = window.wipe_completed
            
            def enhanced_wipe_completed(result):
                original_wipe_completed(result)
                track_wipe_operation(result)
            
            window.wipe_completed = enhanced_wipe_completed
        
        print("✅ Professional dashboard integrated successfully")
        return True
        
    except ImportError as e:
        print(f"⚠️ Dashboard features not available: {e}")
        return False
    except Exception as e:
        print(f"⚠️ Failed to integrate dashboard: {e}")
        return False

def main():
    # Create the application
    app = QApplication(sys.argv)
    app.setApplicationName("Zero Trace - Professional E-Waste Data Sanitization")
    app.setStyle('Fusion')
    
    # Check if required backend exists
    if not os.path.exists('file_secure_wipe_optimized.py'):
        QMessageBox.critical(None, "Missing Backend", 
                           "file_secure_wipe_optimized.py not found!\\n"
                           "Please ensure the optimized backend is in the same directory.")
        return 1
    
    try:
        # Try to import the enhanced GUI with loading bar first
        try:
            from zero_trace_enhanced import ZeroTraceEnhanced as ZeroTraceGUI
            print("Using enhanced GUI with loading bar")
        except ImportError:
            # Fall back to standard GUI
            from zero_trace_gui import ZeroTraceGUI
            print("Using standard GUI")
        
        # Create and show the main window
        window = ZeroTraceGUI()
        
        # Add professional dashboard integration
        dashboard_integrated = add_dashboard_to_gui(window)
        
        window.show()
        
        # Show enhanced startup message
        startup_message = """Zero Trace Professional Edition Started

🔒 ALL ALGORITHMS AVAILABLE:
• NIST SP 800-88 Clear (3 passes) - Industry Standard
• DoD 5220.22-M 3-Pass (Military Standard)
• DoD 5220.22-M 7-Pass (High Security)
• Gutmann 35-Pass (Maximum Security)

🌍 ENVIRONMENTAL FEATURES:
• Real-time CO₂ emissions tracking
• E-waste prevention calculations
• Sustainability achievement system
• Professional impact reporting

📜 CERTIFICATE GENERATION:
• PDF and JSON certificates with QR codes
• Professional compliance documentation

⚠️ WARNING: This performs ACTUAL deletion!
Data will be permanently destroyed and cannot be recovered."""

        if dashboard_integrated:
            startup_message += "\\n\\n🌍 Click 'Environmental Impact Dashboard' to track your sustainability impact!"
        
        QMessageBox.information(window, "SecureWipe India - Professional Edition", startup_message)
        
        # Run the application
        return app.exec_()
        
    except ImportError as e:
        QMessageBox.critical(None, "Import Error", 
                           f"Failed to import Zero Trace GUI:\\n{str(e)}\\n\\n"
                           "Please ensure zero_trace_gui.py exists and is properly configured.")
        return 1
    except Exception as e:
        QMessageBox.critical(None, "Startup Error", 
                           f"Failed to start application:\\n{str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
'''
    
    # Write the enhanced main file
    with open('main_fixed_professional.py', 'w', encoding='utf-8') as f:
        f.write(enhanced_main_content)
    
    print("✅ Created main_fixed_professional.py with dashboard integration")

def main():
    """Main integration function"""
    print("🔧 SecureWipe India - Professional Dashboard Integration")
    print("=" * 60)
    
    # Check if required files exist
    required_files = [
        'gamification_engine.py',
        'professional_gamification.py',
        'shareable_certificate.py',
        'zero_trace_gui.py'
    ]
    
    missing_files = [f for f in required_files if not os.path.exists(f)]
    
    if missing_files:
        print(f"❌ Missing required files: {', '.join(missing_files)}")
        print("Please ensure all gamification files are in the same directory.")
        return
    
    # Create backup and enhanced version
    if backup_main_fixed():
        create_enhanced_main()
        
        print("\n✅ Integration completed successfully!")
        print("\n📋 Next Steps:")
        print("1. Run: python main_fixed_professional.py")
        print("2. Click the '🌍 Environmental Impact Dashboard' button")
        print("3. Perform secure wipe operations to earn achievements")
        print("4. Track your environmental impact in real-time")
        
        print("\n📁 Files created:")
        print("• main_fixed_professional.py - Enhanced main file with dashboard")
        print("• main_fixed_backup_*.py - Backup of your original file")
        
    else:
        print("❌ main_fixed.py not found. Creating standalone version...")
        create_enhanced_main()
        print("✅ Created main_fixed_professional.py")

if __name__ == "__main__":
    main()

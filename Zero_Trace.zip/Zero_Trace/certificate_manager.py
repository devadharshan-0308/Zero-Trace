"""
Certificate Manager for Zero Trace Data Sanitization
Generates tamper-proof PDF and JSON certificates with QR codes
"""

import os
import json
import hashlib
import qrcode
from datetime import datetime
from io import BytesIO
import base64

# Try importing reportlab for PDF generation
try:
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader
    from reportlab.lib.colors import HexColor
    from reportlab.platypus import Table, TableStyle
    from reportlab.lib import colors
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False
    print("Warning: reportlab not installed. PDF generation will be limited.")

class CertificateManager:
    """Manages certificate generation for secure deletion operations"""
    
    def __init__(self, output_dir=None):
        """Initialize the certificate manager"""
        if output_dir:
            self.output_dir = output_dir
        else:
            self.output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'certificates')
        
        # Create output directory if it doesn't exist
        os.makedirs(self.output_dir, exist_ok=True)
        
    def generate_certificate_hash(self, data):
        """Generate SHA-256 hash for tamper-proof verification"""
        json_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(json_str.encode()).hexdigest()
    
    def create_certificate_data(self, operation_result, additional_info=None):
        """Create certificate data structure"""
        timestamp = datetime.now()
        
        cert_data = {
            'certificate_id': f"ZT-{timestamp.strftime('%Y%m%d%H%M%S')}-{os.urandom(4).hex()}",
            'certificate_type': 'Zero Trace Data Sanitization Certificate',
            'version': '1.0',
            'timestamp': timestamp.isoformat(),
            'unix_timestamp': int(timestamp.timestamp()),
            
            # Operation details
            'operation': {
                'type': operation_result.get('type', 'unknown'),
                'method': operation_result.get('method', 'NIST Clear'),
                'status': operation_result.get('status', 'unknown'),
                'start_time': operation_result.get('start_time', timestamp.isoformat()),
                'end_time': operation_result.get('end_time', timestamp.isoformat()),
            },
            
            # Results
            'results': {
                'files_processed': operation_result.get('successful', 0) + operation_result.get('failed', 0),
                'files_deleted': operation_result.get('successful', 0),
                'files_failed': operation_result.get('failed', 0),
                'total_passes': self._calculate_passes(operation_result.get('method', '')),
            },
            
            # Compliance
            'compliance': {
                'standards': self._get_compliance_standards(operation_result.get('method', '')),
                'verification_method': 'SHA-256 Hash',
            },
            
            # Additional info if provided
            'additional_info': additional_info or {},
        }
        
        # Add verification hash
        cert_data['verification_hash'] = self.generate_certificate_hash(cert_data)
        
        return cert_data
    
    def _calculate_passes(self, method):
        """Calculate number of passes based on method"""
        if 'NIST' in method:
            return 3
        elif 'DoD 3-Pass' in method:
            return 3
        elif 'DoD 7-Pass' in method:
            return 7
        elif 'Gutmann' in method:
            return 35
        return 3
    
    def _get_compliance_standards(self, method):
        """Get compliance standards based on method"""
        standards = []
        if 'NIST' in method:
            standards.append('NIST SP 800-88 Rev. 1')
        if 'DoD' in method:
            standards.append('DoD 5220.22-M')
        if 'Gutmann' in method:
            standards.append('Gutmann Method')
        return standards if standards else ['Industry Standard']
    
    def generate_qr_code(self, data, size=10):
        """Generate QR code from certificate data"""
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=size,
            border=2,
        )
        
        # Create compact version for QR code
        qr_data = {
            'id': data['certificate_id'],
            'hash': data['verification_hash'],
            'timestamp': data['timestamp'],
            'type': data['operation']['type'],
            'status': data['operation']['status']
        }
        
        qr.add_data(json.dumps(qr_data))
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        return img
    
    def save_json_certificate(self, cert_data, filename=None):
        """Save certificate as JSON file"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"certificate_{timestamp}.json"
        
        filepath = os.path.join(self.output_dir, filename)
        
        with open(filepath, 'w') as f:
            json.dump(cert_data, f, indent=4)
        
        return filepath
    
    def save_pdf_certificate(self, cert_data, filename=None):
        """Generate and save PDF certificate with QR code"""
        if not REPORTLAB_AVAILABLE:
            raise ImportError("reportlab is required for PDF generation. Install it with: pip install reportlab")
        
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"certificate_{timestamp}.pdf"
        
        filepath = os.path.join(self.output_dir, filename)
        
        # Create PDF
        c = canvas.Canvas(filepath, pagesize=A4)
        width, height = A4
        
        # Add header with logo/title
        c.setFont("Helvetica-Bold", 24)
        c.drawCentredString(width/2, height - 50, "ZERO TRACE")
        
        c.setFont("Helvetica-Bold", 16)
        c.drawCentredString(width/2, height - 80, "Data Sanitization Certificate")
        
        # Add certificate ID
        c.setFont("Helvetica", 10)
        c.drawCentredString(width/2, height - 100, f"Certificate ID: {cert_data['certificate_id']}")
        
        # Draw a line
        c.line(50, height - 120, width - 50, height - 120)
        
        # Certificate details
        y_position = height - 150
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "OPERATION DETAILS")
        
        y_position -= 25
        c.setFont("Helvetica", 10)
        details = [
            f"Date & Time: {cert_data['timestamp']}",
            f"Operation Type: {cert_data['operation']['type'].upper()}",
            f"Sanitization Method: {cert_data['operation']['method']}",
            f"Status: {cert_data['operation']['status'].upper()}",
        ]
        
        for detail in details:
            c.drawString(70, y_position, detail)
            y_position -= 20
        
        # Results section
        y_position -= 10
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "RESULTS")
        
        y_position -= 25
        c.setFont("Helvetica", 10)
        results = [
            f"Files Processed: {cert_data['results']['files_processed']}",
            f"Files Successfully Deleted: {cert_data['results']['files_deleted']}",
            f"Files Failed: {cert_data['results']['files_failed']}",
            f"Total Overwrite Passes: {cert_data['results']['total_passes']}",
        ]
        
        for result in results:
            c.drawString(70, y_position, result)
            y_position -= 20
        
        # Compliance section
        y_position -= 10
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "COMPLIANCE & STANDARDS")
        
        y_position -= 25
        c.setFont("Helvetica", 10)
        standards_text = ", ".join(cert_data['compliance']['standards'])
        c.drawString(70, y_position, f"Standards: {standards_text}")
        y_position -= 20
        c.drawString(70, y_position, f"Verification: {cert_data['compliance']['verification_method']}")
        
        # Verification hash
        y_position -= 30
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y_position, "VERIFICATION HASH")
        
        y_position -= 25
        c.setFont("Courier", 8)
        hash_text = cert_data['verification_hash']
        # Split hash into two lines for better display
        c.drawString(70, y_position, hash_text[:32])
        y_position -= 15
        c.drawString(70, y_position, hash_text[32:])
        
        # Generate and add QR code
        qr_img = self.generate_qr_code(cert_data, size=5)
        
        # Save QR to BytesIO
        qr_buffer = BytesIO()
        qr_img.save(qr_buffer, format='PNG')
        qr_buffer.seek(0)
        
        # Add QR code to PDF
        qr_size = 150
        c.drawImage(ImageReader(qr_buffer), width - qr_size - 50, 100, qr_size, qr_size)
        
        # Add QR code label
        c.setFont("Helvetica", 8)
        c.drawCentredString(width - qr_size/2 - 50, 85, "Scan for Verification")
        
        # Footer
        c.setFont("Helvetica-Oblique", 8)
        c.drawCentredString(width/2, 50, "This certificate confirms the secure and irreversible deletion of data")
        c.drawCentredString(width/2, 35, "in accordance with industry standards and best practices.")
        
        # Save the PDF
        c.save()
        
        return filepath
    
    def generate_complete_certificate(self, operation_result, save_qr_separately=True):
        """Generate complete certificate package (JSON, PDF, and QR code)"""
        try:
            # Create certificate data
            cert_data = self.create_certificate_data(operation_result)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            cert_id = cert_data['certificate_id']
            
            results = {
                'success': True,
                'certificate_id': cert_id,
                'files': {}
            }
            
            # Save JSON certificate
            try:
                json_file = self.save_json_certificate(cert_data, f"{cert_id}.json")
                results['files']['json'] = json_file
                print(f"✅ JSON certificate saved: {json_file}")
            except Exception as e:
                print(f"❌ Failed to save JSON certificate: {e}")
                results['success'] = False
            
            # Save PDF certificate
            try:
                if REPORTLAB_AVAILABLE:
                    pdf_file = self.save_pdf_certificate(cert_data, f"{cert_id}.pdf")
                    results['files']['pdf'] = pdf_file
                    print(f"✅ PDF certificate saved: {pdf_file}")
                else:
                    print("⚠️ PDF generation skipped (reportlab not installed)")
            except Exception as e:
                print(f"❌ Failed to save PDF certificate: {e}")
                results['success'] = False
            
            # Save QR code separately if requested
            if save_qr_separately:
                try:
                    qr_img = self.generate_qr_code(cert_data)
                    qr_path = os.path.join(self.output_dir, f"{cert_id}_qr.png")
                    qr_img.save(qr_path)
                    results['files']['qr'] = qr_path
                    print(f"✅ QR code saved: {qr_path}")
                except Exception as e:
                    print(f"❌ Failed to save QR code: {e}")
            
            return results
            
        except Exception as e:
            print(f"❌ Certificate generation failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'certificate_id': None,
                'files': {}
            }
    
    def verify_certificate(self, cert_file_path):
        """Verify the integrity of a certificate"""
        try:
            with open(cert_file_path, 'r') as f:
                cert_data = json.load(f)
            
            stored_hash = cert_data.get('verification_hash', '')
            
            # Remove the hash from data to recalculate
            cert_data_copy = cert_data.copy()
            if 'verification_hash' in cert_data_copy:
                del cert_data_copy['verification_hash']
            
            calculated_hash = self.generate_certificate_hash(cert_data_copy)
            
            return {
                'valid': stored_hash == calculated_hash,
                'stored_hash': stored_hash,
                'calculated_hash': calculated_hash,
                'certificate_id': cert_data.get('certificate_id', 'Unknown')
            }
        except Exception as e:
            return {
                'valid': False,
                'error': str(e)
            }


# Example usage and testing
if __name__ == "__main__":
    # Test the certificate manager
    manager = CertificateManager()
    
    # Sample operation result
    test_result = {
        'type': 'files',
        'status': 'completed',
        'successful': 5,
        'failed': 0,
        'method': 'NIST Clear (3 passes)',
        'start_time': datetime.now().isoformat(),
        'end_time': datetime.now().isoformat()
    }
    
    # Generate certificates
    result = manager.generate_complete_certificate(test_result)
    
    if result['success']:
        print(f"\n✅ Certificates generated successfully!")
        print(f"Certificate ID: {result['certificate_id']}")
        for file_type, path in result['files'].items():
            print(f"  - {file_type.upper()}: {path}")
        
        # Verify the certificate
        if 'json' in result['files']:
            verification = manager.verify_certificate(result['files']['json'])
            if verification['valid']:
                print(f"\n✅ Certificate verification: VALID")
            else:
                print(f"\n❌ Certificate verification: INVALID")
    else:
        print(f"\n❌ Certificate generation failed!")

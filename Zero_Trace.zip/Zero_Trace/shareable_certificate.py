"""
Shareable certificates for social media sharing
"""
import json
from datetime import datetime
from typing import Dict
from gamification_engine import GamificationEngine

class ShareableCertificate:
    def __init__(self):
        self.gamification = GamificationEngine()
    
    def generate_shareable_content(self, user_id: str, session_id: str = None) -> Dict:
        """Generate content for social media sharing"""
        stats = self.gamification.get_user_stats(user_id)
        
        # Create shareable message
        if session_id:
            message = f"🔒 Just securely wiped data and saved {stats['total_co2_saved_kg']:.1f}kg CO₂!"
        else:
            message = f"🌍 I've saved {stats['total_co2_saved_kg']:.1f}kg CO₂ through secure e-waste recycling!"
        
        content = {
            'message': message,
            'hashtags': '#SecureWipeIndia #EcoFriendly #DataSecurity #GreenIT',
            'stats': {
                'devices_wiped': stats['total_devices_wiped'],
                'co2_saved': stats['total_co2_saved_kg'],
                'ewaste_prevented': stats['total_ewaste_saved_kg'],
                'achievements_count': len(stats['achievements'])
            },
            'image_suggestion': self.generate_image_suggestion(stats)
        }
        
        return content
    
    def generate_image_suggestion(self, stats: Dict) -> str:
        """Generate suggestions for shareable images"""
        if stats['total_co2_saved_kg'] > 1000:
            return "carbon_hero.png"
        elif stats['total_devices_wiped'] > 50:
            return "data_guardian.png"
        elif stats['total_devices_wiped'] > 10:
            return "eco_saver.png"
        else:
            return "starter.png"

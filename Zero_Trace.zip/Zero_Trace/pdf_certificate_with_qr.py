"""
Enhanced PDF Certificate Generator with QR Code
Adds QR code for verification and tracking to certificates
"""

import os
import json
import hashlib
from datetime import datetime
from typing import Dict, Any
import io
import base64

# QR Code generation
try:
    import qrcode
    from PIL import Image
    QRCODE_AVAILABLE = True
except ImportError:
    QRCODE_AVAILABLE = False

# PDF generation
try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image as RLImage
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
    from reportlab.pdfgen import canvas
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

def install_dependencies():
    """Install required dependencies"""
    import subprocess
    import sys
    
    packages = []
    if not REPORTLAB_AVAILABLE:
        packages.append('reportlab')
    if not QRCODE_AVAILABLE:
        packages.append('qrcode[pil]')
    
    if packages:
        print(f"📦 Installing required packages: {', '.join(packages)}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + packages)
            print("✅ Packages installed successfully!")
            return True
        except Exception as e:
            print(f"❌ Failed to install packages: {e}")
            print(f"Please install manually: pip install {' '.join(packages)}")
            return False
    return True

class EnhancedPDFCertificateGenerator:
    """Generate PDF certificates with QR codes"""
    
    def __init__(self):
        if not REPORTLAB_AVAILABLE or not QRCODE_AVAILABLE:
            if install_dependencies():
                # Try to import again
                try:
                    global qrcode, Image, RLImage, SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
                    global getSampleStyleSheet, ParagraphStyle, inch, TA_CENTER, TA_LEFT, TA_JUSTIFY
                    global canvas, colors, letter, A4
                    
                    import qrcode
                    from PIL import Image
                    from reportlab.lib import colors
                    from reportlab.lib.pagesizes import letter, A4
                    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image as RLImage
                    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
                    from reportlab.lib.units import inch
                    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
                    from reportlab.pdfgen import canvas
                except ImportError:
                    raise ImportError("Required packages (reportlab, qrcode) are needed")
            else:
                raise ImportError("Required packages (reportlab, qrcode) are needed")
        
        self.styles = getSampleStyleSheet()
        self._create_custom_styles()
    
    def _create_custom_styles(self):
        """Create custom styles for the certificate"""
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Title'],
            fontSize=24,
            textColor=colors.HexColor('#1e3a8a'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        self.heading_style = ParagraphStyle(
            'CustomHeading',
            parent=self.styles['Heading1'],
            fontSize=14,
            textColor=colors.HexColor('#1e3a8a'),
            spaceAfter=12,
            fontName='Helvetica-Bold'
        )
        
        self.body_style = ParagraphStyle(
            'CustomBody',
            parent=self.styles['BodyText'],
            fontSize=11,
            alignment=TA_JUSTIFY,
            spaceAfter=12
        )
        
        self.cert_number_style = ParagraphStyle(
            'CertNumber',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.grey,
            alignment=TA_CENTER
        )
    
    def generate_qr_code(self, data: Dict[str, Any], cert_number: str) -> io.BytesIO:
        """Generate QR code for certificate verification"""
        # Create verification data
        verification_data = {
            'cert_number': cert_number,
            'timestamp': data.get('timestamp', datetime.now().isoformat()),
            'operation': data.get('operation', 'unknown'),
            'status': data.get('status', 'unknown'),
            'method': data.get('method', 'NIST Clear'),
            'hash': hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()[:16]
        }
        
        # Create QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        
        # Add verification URL or data
        qr_content = json.dumps(verification_data, separators=(',', ':'))
        # Alternative: Use a verification URL
        # qr_content = f"https://zerotrace.verify/{cert_number}"
        
        qr.add_data(qr_content)
        qr.make(fit=True)
        
        # Create QR code image
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Save to BytesIO
        img_buffer = io.BytesIO()
        img.save(img_buffer, format='PNG')
        img_buffer.seek(0)
        
        return img_buffer
    
    def generate_certificate(self, cert_data: Dict[str, Any], output_path: str) -> bool:
        """Generate PDF certificate with QR code"""
        try:
            # Generate certificate number
            cert_number = f"ZT-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
            # Generate QR code
            qr_buffer = self.generate_qr_code(cert_data, cert_number)
            
            # Save QR code temporarily
            qr_temp_path = f"temp_qr_{cert_number}.png"
            with open(qr_temp_path, 'wb') as f:
                f.write(qr_buffer.getvalue())
            
            # Create PDF document
            doc = SimpleDocTemplate(
                output_path,
                pagesize=letter,
                rightMargin=72,
                leftMargin=72,
                topMargin=72,
                bottomMargin=72
            )
            
            story = []
            
            # Header with title
            story.append(Paragraph("🔷 ZERO TRACE", self.title_style))
            story.append(Paragraph("Data Sanitization Certificate", self.title_style))
            story.append(Spacer(1, 0.2*inch))
            
            # Certificate number
            story.append(Paragraph(f"Certificate No: {cert_number}", self.cert_number_style))
            story.append(Spacer(1, 0.2*inch))
            
            # Add QR code (positioned on the right)
            qr_table_data = [[
                Paragraph("CERTIFICATE OF DATA DESTRUCTION", self.heading_style),
                RLImage(qr_temp_path, width=1.5*inch, height=1.5*inch)
            ]]
            
            qr_table = Table(qr_table_data, colWidths=[4.5*inch, 2*inch])
            qr_table.setStyle(TableStyle([
                ('ALIGN', (0, 0), (0, 0), 'LEFT'),
                ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ]))
            story.append(qr_table)
            story.append(Spacer(1, 0.2*inch))
            
            # Certification statement
            story.append(Paragraph(
                "This certifies that the data sanitization process has been completed in accordance with "
                "industry standards and best practices for secure data destruction.",
                self.body_style
            ))
            story.append(Spacer(1, 0.2*inch))
            
            # Operation details
            story.append(Paragraph("OPERATION DETAILS", self.heading_style))
            
            # Details table
            operation_data = [
                ['Field', 'Value'],
                ['Date & Time', datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
                ['Operation Type', cert_data.get('operation', 'Unknown').upper()],
                ['Sanitization Method', cert_data.get('method', 'NIST Clear')],
                ['Status', cert_data.get('status', 'Unknown').upper()],
            ]
            
            # Add specific details
            details = cert_data.get('details', {})
            if details.get('type') == 'device':
                operation_data.extend([
                    ['Device Path', details.get('device_path', 'N/A')],
                    ['Files Wiped', str(details.get('files_deleted', 0))],
                    ['Files Failed', str(details.get('files_failed', 0))],
                    ['Files Locked', str(details.get('files_locked', 0))],
                    ['Files Skipped', str(details.get('files_skipped', 0))],
                ])
            else:
                operation_data.extend([
                    ['Total Files', str(details.get('total', 0))],
                    ['Successfully Wiped', str(details.get('successful', 0))],
                    ['Failed', str(details.get('failed', 0))],
                ])
            
            table = Table(operation_data, colWidths=[2.5*inch, 3.5*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.grey),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey]),
            ]))
            
            story.append(table)
            story.append(Spacer(1, 0.3*inch))
            
            # Compliance section
            story.append(Paragraph("COMPLIANCE STANDARDS", self.heading_style))
            compliance_text = """
            This data sanitization process complies with:
            • NIST SP 800-88 Rev. 1 Guidelines for Media Sanitization
            • DoD 5220.22-M Data Sanitization Standards
            • ISO/IEC 27001:2013 Information Security Management
            """
            story.append(Paragraph(compliance_text, self.body_style))
            story.append(Spacer(1, 0.2*inch))
            
            # QR Code verification info
            story.append(Paragraph("VERIFICATION", self.heading_style))
            verification_text = f"""
            Scan the QR code above to verify this certificate's authenticity.
            The QR code contains encrypted verification data including:
            • Certificate number: {cert_number}
            • Operation timestamp and details
            • Cryptographic hash for integrity verification
            
            This certificate can be independently verified using the QR code data.
            """
            story.append(Paragraph(verification_text, self.body_style))
            story.append(Spacer(1, 0.2*inch))
            
            # Signature section
            story.append(Paragraph("AUTHORIZED BY", self.heading_style))
            story.append(Spacer(1, 0.2*inch))
            
            signature_data = [
                ['_' * 40, '_' * 40],
                ['Authorized Signature', 'Date'],
                ['', ''],
                ['Zero Trace Data Sanitization System', datetime.now().strftime('%Y-%m-%d')],
            ]
            
            sig_table = Table(signature_data, colWidths=[3*inch, 3*inch])
            sig_table.setStyle(TableStyle([
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 1), (-1, 1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
            ]))
            
            story.append(sig_table)
            story.append(Spacer(1, 0.2*inch))
            
            # Footer with QR verification note
            footer_text = f"""
            <para align="center">
            <font size="8" color="grey">
            Certificate No: {cert_number} | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}<br/>
            Zero Trace E-Waste Data Sanitization System - Secure Data Destruction<br/>
            QR Code contains verification data - Scan to verify authenticity
            </font>
            </para>
            """
            story.append(Paragraph(footer_text, self.styles['Normal']))
            
            # Build PDF
            doc.build(story)
            
            # Clean up temp QR file
            try:
                os.remove(qr_temp_path)
            except:
                pass
            
            print(f"✅ PDF certificate with QR code generated: {output_path}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to generate PDF certificate: {e}")
            # Clean up temp file if exists
            try:
                if 'qr_temp_path' in locals():
                    os.remove(qr_temp_path)
            except:
                pass
            return False

def test_certificate_with_qr():
    """Test certificate generation with QR code"""
    test_data = {
        'certificate_type': 'Zero Trace Data Sanitization Certificate',
        'timestamp': datetime.now().isoformat(),
        'operation': 'device',
        'method': 'NIST SP 800-88 Clear (3 passes)',
        'status': 'completed',
        'details': {
            'type': 'device',
            'device_path': 'E:\\',
            'files_deleted': 1250,
            'files_failed': 5,
            'files_locked': 3,
            'files_skipped': 150,
            'total': 1408
        }
    }
    
    generator = EnhancedPDFCertificateGenerator()
    output_path = f"certificate_with_qr_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    
    if generator.generate_certificate(test_data, output_path):
        print(f"✅ Test certificate with QR code generated: {output_path}")
        print("📄 The QR code contains verification data")
        print("🔍 Scan the QR code to see the embedded verification information")
        
        # Try to open the PDF
        try:
            import webbrowser
            webbrowser.open(output_path)
        except:
            pass
    else:
        print("❌ Test certificate generation failed")

if __name__ == "__main__":
    print("🔧 Zero Trace PDF Certificate Generator with QR Code")
    print("=" * 50)
    
    if not QRCODE_AVAILABLE or not REPORTLAB_AVAILABLE:
        print("⚠️ Installing required packages...")
        if install_dependencies():
            print("✅ Dependencies installed!")
        else:
            print("❌ Please install manually:")
            print("   pip install reportlab qrcode[pil]")
            exit(1)
    
    print("\n📝 Testing PDF generation with QR code...")
    test_certificate_with_qr()

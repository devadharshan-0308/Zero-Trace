"""
Auto Delete Photos - No confirmation needed
Quickly deletes all photos in specified folder
"""

import os
import sys
import glob
import time
import random
import string

def auto_delete_photos(folder_path):
    """Auto delete all photos in folder - no confirmation"""
    
    # Common image extensions
    image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.gif', '*.bmp', '*.webp']
    
    all_photos = []
    for ext in image_extensions:
        pattern = os.path.join(folder_path, ext)
        all_photos.extend(glob.glob(pattern))
        # Also check uppercase
        pattern_upper = os.path.join(folder_path, ext.upper())
        all_photos.extend(glob.glob(pattern_upper))
    
    if not all_photos:
        print(f"No photos found in: {folder_path}")
        return
    
    print(f"Found {len(all_photos)} photos to delete:")
    for i, photo in enumerate(all_photos, 1):
        print(f"  {i}. {os.path.basename(photo)}")
    
    print(f"\nAuto-deleting {len(all_photos)} photos...")
    start_time = time.time()
    
    successful = 0
    failed = 0
    
    for i, photo_path in enumerate(all_photos, 1):
        try:
            print(f"Processing {i}/{len(all_photos)}: {os.path.basename(photo_path)}")
            
            # Quick secure overwrite
            file_size = os.path.getsize(photo_path)
            
            # Single pass overwrite with zeros (fast for images)
            with open(photo_path, 'r+b') as f:
                f.seek(0)
                f.write(b'\x00' * file_size)
                f.flush()
            
            # Rename to random name
            random_name = ''.join(random.choices(string.ascii_lowercase, k=10))
            temp_path = os.path.join(os.path.dirname(photo_path), random_name + '.tmp')
            os.rename(photo_path, temp_path)
            
            # Delete
            os.remove(temp_path)
            
            successful += 1
            print(f"  [OK] Deleted successfully")
            
        except Exception as e:
            failed += 1
            print(f"  [ERROR] Failed: {e}")
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"\n=== DELETION COMPLETE ===")
    print(f"Successful: {successful}")
    print(f"Failed: {failed}")
    print(f"Total time: {duration:.2f} seconds")
    print(f"Average per file: {duration/len(all_photos):.2f} seconds")
    
    return successful, failed, duration

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python auto_delete_photos.py <folder_path>")
        sys.exit(1)
    
    folder_path = sys.argv[1]
    
    if not os.path.exists(folder_path):
        print(f"Folder not found: {folder_path}")
        sys.exit(1)
    
    auto_delete_photos(folder_path)

# SecureWipe India - Unified Data Destruction System

##  Military-Grade Secure Data Deletion Tool

A powerful, unified application for secure file deletion and partition wiping with military-grade data destruction standards (DoD 5220.22-M).

##  WARNING
**This tool permanently destroys data beyond recovery. Use with extreme caution!**

##  Features

### Dual-Mode Operation
- **File Deletion Mode**: Securely delete individual files or entire folders
- **Partition Wiping Mode**: Complete partition/drive sanitization

### Security Features
- Multiple overwrite passes (1-7 passes)
- DoD 5220.22-M compliant wiping
- Metadata clearing and timestamp removal
- Filename obfuscation before deletion
- Free space wiping for partitions
- Deletion certificates for audit trails

### Performance Optimizations
- No GUI freezing issues
- Optimized chunk sizes (256KB) for faster processing
- Cancellable operations with proper thread management
- Progress tracking for all operations
- Timeout protection for system calls

### User Interface
- Modern, intuitive tabbed interface
- Real-time progress bars
- Detailed operation results
- Context menus for file management
- Administrator privilege detection

##  Requirements

- Python 3.7 or higher
- Windows 10/11 (Administrator privileges required for partition wiping)
- 100MB free disk space

##  Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/securewipe-india.git
cd securewipe-india
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

##  Usage

### Running the Application

**Standard mode (for file deletion):**
```bash
python unified_gui.py
```

**Administrator mode (required for partition wiping):**
- Windows: Right-click and "Run as Administrator"
- Or use the Tools menu → "Run as Administrator"

### File Deletion Mode

1. Click on the "  File Deletion" tab
2. Add files using:
   - "  Add Files" - Select individual files
   - "  Add Folder" - Add all files from a folder
3. Set the number of overwrite passes (3 recommended)
4. Click "  START SECURE WIPE"
5. Confirm the operation

### Partition Wiping Mode

1. **  Ensure you have Administrator privileges**
2. Click on the "  Partition Wiping" tab
3. Click "  Refresh Drives" to see available partitions
4. Select the partition to wipe (be VERY careful!)
5. Set the number of overwrite passes
6. Click "  START SECURE WIPE"
7. Confirm multiple times (includes typing confirmation)

##  Security Standards

### Overwrite Passes
- **1 pass**: Quick wipe with zeros
- **3 passes**: DoD 5220.22-M standard (recommended)
  - Pass 1: Overwrite with zeros (0x00)
  - Pass 2: Overwrite with ones (0xFF)
  - Pass 3: Overwrite with random data
- **7 passes**: High security for sensitive data

### What Gets Deleted
- File contents (overwritten multiple times)
- File metadata and attributes
- Timestamps (creation, modification, access)
- Original filename (obfuscated before deletion)
- Free space (for partition wiping)

##  Project Structure

```
securewipe-india/
├── unified_gui.py           # Main GUI application
├── unified_secure_wipe.py   # Backend wiping engine
├── requirements.txt         # Python dependencies
├── README.md               # This file
└── legacy/                 # Previous versions
    ├── file_gui.py
    ├── file_gui_optimized.py
    ├── file_secure_wipe.py
    └── file_secure_wipe_optimized.py
```

##  Key Improvements Over Previous Versions

1. **Unified Interface**: Single application for both files and partitions
2. **No Freezing**: Removed heavy `cipher /w:` command
3. **Better Performance**: 256KB chunks, optimized algorithms
4. **Cancellation Support**: Proper thread management with cancel buttons
5. **Enhanced UI**: Progress bars, context menus, modern styling
6. **Safety Features**: Multiple confirmations for destructive operations

##  Performance Tips

- Use 3 passes for most scenarios (good balance of security and speed)
- For large files (>100MB), consider using 1 pass
- Close other applications when wiping partitions
- Ensure adequate free space for temporary operations

##  Troubleshooting

### "Administrator privileges required"
- Right-click the application and select "Run as Administrator"
- Or use Tools → Run as Administrator from the menu

### "Access Denied" errors
- Some system files cannot be deleted
- Ensure files are not in use by other programs
- Check file permissions

### Application freezes
- This version has optimizations to prevent freezing
- If issues persist, use the Cancel button
- Report the issue with details

##  Safety Guidelines

1. **Always backup important data** before using this tool
2. **Double-check selections** before confirming operations
3. **Never wipe system partitions** (C:\ on Windows)
4. **Test on non-critical data first** to understand the tool
5. **Keep deletion certificates** for audit purposes

##  Deletion Certificates

After successful operations, generate certificates containing:
- Timestamp of operation
- Files/partitions affected
- Number of overwrite passes used
- Success/failure status
- Detailed operation logs

##  Contributing

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Test thoroughly (use test data!)
4. Submit a pull request

##  License

This project is provided AS IS for educational and security purposes. Use at your own risk.

##  Disclaimer

The developers are not responsible for any data loss resulting from the use of this tool. This software is designed to permanently destroy data - this is its intended function. Always ensure you have proper authorization before using this tool on any system or data.

##  Support

For issues, questions, or suggestions:
- Open an issue on GitHub
- Contact: support@securewipe-india.example

---

**Remember: Deleted data CANNOT be recovered. Think twice, wipe once!**

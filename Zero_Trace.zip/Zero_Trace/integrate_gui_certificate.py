"""
Integration script to add PDF certificate generation to Zero Trace
This will enable proper PDF certificate generation instead of just JSON
"""

import os
import shutil
from datetime import datetime

def integrate_pdf_certificates():
    """Integrate PDF certificate generator into Zero Trace GUI"""
    
    gui_file = "zero_trace_gui.py"
    
    if not os.path.exists(gui_file):
        print(f"❌ {gui_file} not found!")
        return False
    
    if not os.path.exists("pdf_certificate_generator.py"):
        print("❌ pdf_certificate_generator.py not found!")
        print("Please ensure the PDF generator file is in the same directory.")
        return False
    
    # Backup original
    backup_name = f"{gui_file}.backup_pdf_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy(gui_file, backup_name)
    print(f"✅ Backup created: {backup_name}")
    
    # Read the GUI file
    with open(gui_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Add import for PDF generator
    import_addition = """from pdf_certificate_generator import PDFCertificateGenerator, REPORTLAB_AVAILABLE
"""
    
    # Find where to add the import (after other imports)
    import_pos = content.find("from enhanced_wipe_engine import EnhancedWipeEngine")
    if import_pos != -1:
        line_end = content.find("\n", import_pos) + 1
        content = content[:line_end] + import_addition + content[line_end:]
        print("✅ Added PDF certificate generator import")
    
    # Replace the generate_pdf_certificate method
    new_pdf_method = '''    def generate_pdf_certificate(self):
        """Generate a proper PDF certificate"""
        if not self.last_result:
            QMessageBox.warning(self, "No Data", "No wipe operation data available for certificate generation")
            return
        
        file_path, _ = QFileDialog.getSaveFileName(self, "Save PDF Certificate",
                                                   f"ZeroTrace_Certificate_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
                                                   "PDF Files (*.pdf)")
        if file_path:
            # Prepare certificate data
            cert_data = {
                'certificate_type': 'Zero Trace Data Sanitization Certificate',
                'timestamp': datetime.now().isoformat(),
                'operation': self.last_result.get('type', 'unknown'),
                'method': self.last_result.get('method', 'NIST Clear'),
                'status': self.last_result.get('status', 'unknown'),
                'details': self.last_result
            }
            
            # Check if reportlab is available
            if not REPORTLAB_AVAILABLE:
                # Try to install reportlab
                reply = QMessageBox.question(self, "Install PDF Library",
                                           "PDF generation requires the 'reportlab' library.\\n"
                                           "Would you like to install it now?",
                                           QMessageBox.Yes | QMessageBox.No,
                                           QMessageBox.Yes)
                if reply == QMessageBox.Yes:
                    try:
                        import subprocess
                        import sys
                        subprocess.check_call([sys.executable, "-m", "pip", "install", "reportlab"])
                        QMessageBox.information(self, "Success", "reportlab installed successfully!\\nPlease try generating the certificate again.")
                        return
                    except Exception as e:
                        QMessageBox.critical(self, "Installation Failed", 
                                           f"Failed to install reportlab:\\n{e}\\n\\n"
                                           "Please install manually: pip install reportlab")
                        # Fall back to JSON
                        json_path = file_path.replace('.pdf', '.json')
                        with open(json_path, 'w') as f:
                            json.dump(cert_data, f, indent=2)
                        QMessageBox.information(self, "JSON Certificate Generated",
                                              f"PDF generation unavailable. JSON certificate saved:\\n{json_path}")
                        self.log_message(f"📋 JSON certificate generated: {os.path.basename(json_path)}")
                        return
                else:
                    # User declined, save as JSON
                    json_path = file_path.replace('.pdf', '.json')
                    with open(json_path, 'w') as f:
                        json.dump(cert_data, f, indent=2)
                    QMessageBox.information(self, "JSON Certificate Generated",
                                          f"JSON certificate saved:\\n{json_path}")
                    self.log_message(f"📋 JSON certificate generated: {os.path.basename(json_path)}")
                    return
            
            # Generate PDF certificate
            try:
                generator = PDFCertificateGenerator()
                if generator.generate_certificate(cert_data, file_path):
                    QMessageBox.information(self, "Certificate Generated",
                                          f"PDF certificate successfully generated:\\n{file_path}")
                    self.log_message(f"📄 PDF certificate generated: {os.path.basename(file_path)}")
                    
                    # Also save JSON version for records
                    json_path = file_path.replace('.pdf', '.json')
                    with open(json_path, 'w') as f:
                        json.dump(cert_data, f, indent=2)
                    self.log_message(f"📋 JSON backup saved: {os.path.basename(json_path)}")
                    
                    # Try to open the PDF
                    try:
                        import webbrowser
                        webbrowser.open(file_path)
                    except:
                        pass
                else:
                    QMessageBox.warning(self, "Generation Failed",
                                      "Failed to generate PDF certificate. Check the console for details.")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to generate PDF certificate:\\n{e}")
                # Fall back to JSON
                json_path = file_path.replace('.pdf', '.json')
                with open(json_path, 'w') as f:
                    json.dump(cert_data, f, indent=2)
                QMessageBox.information(self, "JSON Certificate Generated",
                                      f"PDF generation failed. JSON certificate saved:\\n{json_path}")
                self.log_message(f"📋 JSON certificate generated: {os.path.basename(json_path)}")'''
    
    # Find and replace the generate_pdf_certificate method
    start_marker = "    def generate_pdf_certificate(self):"
    start_pos = content.find(start_marker)
    if start_pos != -1:
        # Find the next method
        next_method = content.find("\n    def ", start_pos + 1)
        if next_method != -1:
            content = content[:start_pos] + new_pdf_method + content[next_method:]
            print("✅ Updated generate_pdf_certificate method")
    
    # Write the updated content
    with open(gui_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ PDF certificate generation integrated successfully!")
    return True

def main():
    """Main integration function"""
    print("🔧 Zero Trace PDF Certificate Integration")
    print("=" * 50)
    print("This will enable proper PDF certificate generation")
    print("Features:")
    print("  ✅ Professional PDF certificates")
    print("  ✅ Compliance documentation")
    print("  ✅ Detailed operation reports")
    print("  ✅ Automatic reportlab installation")
    print("=" * 50)
    
    if integrate_pdf_certificates():
        print("\n🎉 Integration complete!")
        print("PDF certificate generation is now available.")
        print("\n📋 What's new:")
        print("  - Professional PDF certificates with Zero Trace branding")
        print("  - Detailed operation summaries")
        print("  - Compliance standards documentation")
        print("  - Automatic signature and timestamp")
        print("  - JSON backup for records")
        print("\n🚀 Run: python main_fixed.py")
        print("You can now generate proper PDF certificates!")
        
        # Test if reportlab is installed
        try:
            import reportlab
            print("\n✅ reportlab is already installed - PDF generation ready!")
        except ImportError:
            print("\n⚠️ reportlab is not installed yet")
            print("The first time you generate a PDF, you'll be prompted to install it.")
            print("Or install now: pip install reportlab")
    else:
        print("❌ Integration failed")

if __name__ == "__main__":
    main()

import os
import shutil
import tempfile
from Cryptodome.Cipher import AES
from Cryptodome.Random import get_random_bytes

# ------------------ Encryption ------------------
def encrypt_file(file_path):
    key = get_random_bytes(32)  # AES-256 key
    cipher = AES.new(key, AES.MODE_EAX)

    with open(file_path, 'rb') as f:
        data = f.read()

    ciphertext, tag = cipher.encrypt_and_digest(data)

    enc_file_path = file_path + ".enc"
    with open(enc_file_path, 'wb') as ef:
        for x in (cipher.nonce, tag, ciphertext):
            ef.write(x)

    # Do NOT save key permanently, just keep in memory
    return enc_file_path, key

def wipe_key(key):
    """Overwrite key bytes in memory"""
    key_bytes = bytearray(key)
    for i in range(len(key_bytes)):
        key_bytes[i] = 0
    del key_bytes

# ------------------ Overwrite ------------------
def overwrite_file(file_path, passes=3):
    try:
        length = os.path.getsize(file_path)
        with open(file_path, "r+b") as f:
            for _ in range(passes):
                f.seek(0)
                f.write(os.urandom(length))
        return True
    except Exception as e:
        print(f"[!] Overwrite failed: {e}")
        return False

# ------------------ Delete ------------------
def delete_file(path):
    try:
        if os.path.isfile(path):
            os.remove(path)
        elif os.path.isdir(path):
            shutil.rmtree(path)
    except Exception as e:
        print(f"[!] Delete failed: {e}")

# ------------------ Main Secure Delete ------------------
def secure_delete(file_path):
    print("[*] Encrypting file...")
    enc_file_path, key = encrypt_file(file_path)

    print("[*] Wiping encryption key from memory...")
    wipe_key(key)

    print("[*] Overwriting original file...")
    overwrite_file(file_path)

    print("[*] Deleting files...")
    delete_file(file_path)
    delete_file(enc_file_path)

    print("[+] Secure delete completed.")

# ------------------ Run ------------------
if __name__ == "__main__":
    target_file = input("Enter file path to securely delete: ").strip()
    secure_delete(target_file)

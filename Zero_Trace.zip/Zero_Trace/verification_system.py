"""
Third-party Verification System for Secure Data Wiping Certificates
Enables independent verification of wipe status and certificate authenticity
"""

import json
import hashlib
import requests
from typing import Dict, Optional, List
from datetime import datetime
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.exceptions import InvalidSignature
import sqlite3
import os

class VerificationDatabase:
    """Local database for storing verification records"""
    
    def __init__(self, db_path: str = "verification_records.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize verification database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS verification_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                certificate_id TEXT UNIQUE NOT NULL,
                device_serial TEXT,
                verification_hash TEXT,
                timestamp TEXT,
                status TEXT,
                verifier_info TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS public_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_id TEXT UNIQUE NOT NULL,
                public_key_pem TEXT NOT NULL,
                issuer TEXT,
                valid_from TEXT,
                valid_until TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def store_verification_record(self, record: Dict) -> bool:
        """Store verification record in database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO verification_records 
                (certificate_id, device_serial, verification_hash, timestamp, status, verifier_info)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                record['certificate_id'],
                record.get('device_serial', ''),
                record.get('verification_hash', ''),
                record.get('timestamp', ''),
                record.get('status', ''),
                json.dumps(record.get('verifier_info', {}))
            ))
            
            conn.commit()
            conn.close()
            return True
            
        except Exception as e:
            print(f"Database storage failed: {e}")
            return False
    
    def get_verification_record(self, certificate_id: str) -> Optional[Dict]:
        """Retrieve verification record"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM verification_records WHERE certificate_id = ?
            ''', (certificate_id,))
            
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return {
                    'id': row[0],
                    'certificate_id': row[1],
                    'device_serial': row[2],
                    'verification_hash': row[3],
                    'timestamp': row[4],
                    'status': row[5],
                    'verifier_info': json.loads(row[6]) if row[6] else {},
                    'created_at': row[7]
                }
            
            return None
            
        except Exception as e:
            print(f"Database retrieval failed: {e}")
            return None

class ThirdPartyVerifier:
    """Third-party verification system for wipe certificates"""
    
    def __init__(self):
        self.db = VerificationDatabase()
        self.trusted_issuers = self._load_trusted_issuers()
    
    def _load_trusted_issuers(self) -> Dict:
        """Load trusted certificate issuers"""
        return {
            'SecureWipe India': {
                'public_key_url': 'https://securewipe.india.gov.in/public_key.pem',
                'verification_endpoint': 'https://securewipe.india.gov.in/verify',
                'trusted': True
            }
        }
    
    def verify_certificate_signature(self, certificate: Dict, public_key_pem: str) -> bool:
        """Verify certificate digital signature"""
        try:
            # Extract signature
            signature_hex = certificate.get('digital_signature', '')
            if not signature_hex:
                return False
            
            signature = bytes.fromhex(signature_hex)
            
            # Create certificate data without signature
            cert_copy = certificate.copy()
            cert_copy.pop('digital_signature', None)
            certificate_json = json.dumps(cert_copy, sort_keys=True)
            
            # Load public key
            public_key = serialization.load_pem_public_key(public_key_pem.encode())
            
            # Verify signature
            public_key.verify(
                signature,
                certificate_json.encode(),
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            return True
            
        except (InvalidSignature, Exception) as e:
            print(f"Signature verification failed: {e}")
            return False
    
    def verify_certificate_integrity(self, certificate: Dict) -> Dict:
        """Comprehensive certificate integrity verification"""
        verification_result = {
            'valid': False,
            'checks': {},
            'errors': [],
            'warnings': []
        }
        
        # Check required fields
        required_fields = [
            'certificate_id', 'timestamp', 'device_info', 
            'wipe_details', 'compliance', 'digital_signature'
        ]
        
        for field in required_fields:
            if field not in certificate:
                verification_result['errors'].append(f"Missing required field: {field}")
            else:
                verification_result['checks'][f'{field}_present'] = True
        
        # Check certificate age
        try:
            cert_timestamp = datetime.fromisoformat(certificate.get('timestamp', ''))
            age_days = (datetime.now() - cert_timestamp).days
            
            if age_days > 365:
                verification_result['warnings'].append(f"Certificate is {age_days} days old")
            
            verification_result['checks']['timestamp_valid'] = True
            
        except Exception:
            verification_result['errors'].append("Invalid timestamp format")
        
        # Check wipe method compliance
        wipe_details = certificate.get('wipe_details', {})
        method = wipe_details.get('method', '')
        
        if method in ['NIST_Clear', 'NIST_Purge', 'DoD_3Pass', 'DoD_7Pass']:
            verification_result['checks']['method_compliant'] = True
        else:
            verification_result['warnings'].append(f"Unknown wipe method: {method}")
        
        # Check compliance standard
        compliance = certificate.get('compliance', {})
        if compliance.get('standard') == 'NIST SP 800-88':
            verification_result['checks']['nist_compliant'] = True
        else:
            verification_result['warnings'].append("Not NIST SP 800-88 compliant")
        
        # Overall validity
        verification_result['valid'] = len(verification_result['errors']) == 0
        
        return verification_result
    
    def verify_device_wipe_status(self, certificate: Dict) -> Dict:
        """Verify actual device wipe status"""
        device_info = certificate.get('device_info', {})
        wipe_details = certificate.get('wipe_details', {})
        
        verification_result = {
            'device_accessible': False,
            'wipe_verified': False,
            'verification_hash_match': False,
            'details': {}
        }
        
        try:
            device_path = device_info.get('device_path', '')
            expected_hash = wipe_details.get('verification_hash', '')
            
            if os.path.exists(device_path):
                verification_result['device_accessible'] = True
                
                # Generate current verification hash
                current_hash = self._generate_device_hash(device_path)
                
                if current_hash == expected_hash:
                    verification_result['verification_hash_match'] = True
                    verification_result['wipe_verified'] = True
                else:
                    verification_result['details']['hash_mismatch'] = {
                        'expected': expected_hash,
                        'current': current_hash
                    }
            else:
                verification_result['details']['device_not_found'] = device_path
                
        except Exception as e:
            verification_result['details']['error'] = str(e)
        
        return verification_result
    
    def _generate_device_hash(self, device_path: str) -> str:
        """Generate verification hash for device"""
        try:
            hasher = hashlib.sha256()
            chunk_size = 1024 * 1024  # 1MB chunks
            
            with open(device_path, 'rb') as device:
                # Sample first 100MB for verification
                bytes_read = 0
                max_bytes = 100 * 1024 * 1024
                
                while bytes_read < max_bytes:
                    chunk = device.read(min(chunk_size, max_bytes - bytes_read))
                    if not chunk:
                        break
                    hasher.update(chunk)
                    bytes_read += len(chunk)
            
            return hasher.hexdigest()
            
        except Exception:
            return "verification_failed"
    
    def perform_full_verification(self, certificate: Dict, public_key_pem: Optional[str] = None) -> Dict:
        """Perform comprehensive certificate verification"""
        full_result = {
            'certificate_id': certificate.get('certificate_id', 'unknown'),
            'verification_timestamp': datetime.now().isoformat(),
            'overall_valid': False,
            'signature_valid': False,
            'integrity_check': {},
            'device_verification': {},
            'trust_level': 'unknown'
        }
        
        # 1. Integrity verification
        integrity_result = self.verify_certificate_integrity(certificate)
        full_result['integrity_check'] = integrity_result
        
        # 2. Signature verification
        if public_key_pem:
            signature_valid = self.verify_certificate_signature(certificate, public_key_pem)
            full_result['signature_valid'] = signature_valid
        
        # 3. Device verification (if accessible)
        device_result = self.verify_device_wipe_status(certificate)
        full_result['device_verification'] = device_result
        
        # 4. Determine trust level
        issuer = certificate.get('issuer', {}).get('organization', 'unknown')
        if issuer in self.trusted_issuers:
            full_result['trust_level'] = 'trusted'
        else:
            full_result['trust_level'] = 'untrusted'
        
        # 5. Overall validity
        full_result['overall_valid'] = (
            integrity_result['valid'] and
            full_result['signature_valid'] and
            len(integrity_result['errors']) == 0
        )
        
        # Store verification record
        self.db.store_verification_record({
            'certificate_id': full_result['certificate_id'],
            'device_serial': certificate.get('device_info', {}).get('serial_number', ''),
            'verification_hash': certificate.get('wipe_details', {}).get('verification_hash', ''),
            'timestamp': full_result['verification_timestamp'],
            'status': 'valid' if full_result['overall_valid'] else 'invalid',
            'verifier_info': {
                'trust_level': full_result['trust_level'],
                'signature_valid': full_result['signature_valid'],
                'integrity_errors': integrity_result.get('errors', [])
            }
        })
        
        return full_result
    
    def verify_certificate_file(self, file_path: str, public_key_pem: Optional[str] = None) -> Dict:
        """Verify certificate from file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                if file_path.endswith('.json'):
                    data = json.load(f)
                    certificate = data.get('certificate', data)
                else:
                    return {
                        'error': 'PDF verification requires specialized parsing',
                        'overall_valid': False
                    }
            
            return self.perform_full_verification(certificate, public_key_pem)
            
        except Exception as e:
            return {
                'error': f'File verification failed: {e}',
                'overall_valid': False
            }
    
    def generate_verification_report(self, verification_result: Dict) -> str:
        """Generate human-readable verification report"""
        report = []
        report.append("=== CERTIFICATE VERIFICATION REPORT ===")
        report.append(f"Certificate ID: {verification_result.get('certificate_id', 'Unknown')}")
        report.append(f"Verification Time: {verification_result.get('verification_timestamp', 'Unknown')}")
        report.append("")
        
        # Overall status
        if verification_result.get('overall_valid', False):
            report.append("✅ CERTIFICATE IS VALID")
        else:
            report.append("❌ CERTIFICATE VERIFICATION FAILED")
        
        report.append("")
        
        # Detailed checks
        report.append("--- Detailed Verification Results ---")
        
        # Signature verification
        if verification_result.get('signature_valid', False):
            report.append("✅ Digital signature is valid")
        else:
            report.append("❌ Digital signature verification failed")
        
        # Integrity check
        integrity = verification_result.get('integrity_check', {})
        if integrity.get('valid', False):
            report.append("✅ Certificate integrity verified")
        else:
            report.append("❌ Certificate integrity check failed")
            
            errors = integrity.get('errors', [])
            for error in errors:
                report.append(f"   • {error}")
        
        # Device verification
        device_check = verification_result.get('device_verification', {})
        if device_check.get('wipe_verified', False):
            report.append("✅ Device wipe status verified")
        elif device_check.get('device_accessible', False):
            report.append("⚠️ Device accessible but wipe verification failed")
        else:
            report.append("⚠️ Device not accessible for verification")
        
        # Trust level
        trust_level = verification_result.get('trust_level', 'unknown')
        if trust_level == 'trusted':
            report.append("✅ Certificate issued by trusted authority")
        else:
            report.append("⚠️ Certificate issuer not in trusted list")
        
        report.append("")
        report.append("=== END OF REPORT ===")
        
        return "\n".join(report)
    
    def get_verification_history(self, certificate_id: str) -> List[Dict]:
        """Get verification history for a certificate"""
        try:
            conn = sqlite3.connect(self.db.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM verification_records 
                WHERE certificate_id = ? 
                ORDER BY created_at DESC
            ''', (certificate_id,))
            
            rows = cursor.fetchall()
            conn.close()
            
            history = []
            for row in rows:
                history.append({
                    'verification_id': row[0],
                    'certificate_id': row[1],
                    'device_serial': row[2],
                    'verification_hash': row[3],
                    'timestamp': row[4],
                    'status': row[5],
                    'verifier_info': json.loads(row[6]) if row[6] else {},
                    'created_at': row[7]
                })
            
            return history
            
        except Exception as e:
            print(f"History retrieval failed: {e}")
            return []

# Example usage and testing
if __name__ == "__main__":
    verifier = ThirdPartyVerifier()
    
    # Example certificate for testing
    test_certificate = {
        'certificate_id': 'test-cert-123',
        'timestamp': datetime.now().isoformat(),
        'device_info': {
            'device_path': '/dev/sda',
            'serial_number': 'TEST123456',
            'model': 'Test Drive',
            'storage_type': 'SSD'
        },
        'wipe_details': {
            'method': 'NIST_Clear',
            'status': 'completed',
            'verification_hash': 'abcd1234567890'
        },
        'compliance': {
            'standard': 'NIST SP 800-88'
        },
        'issuer': {
            'organization': 'SecureWipe India'
        },
        'digital_signature': 'dummy_signature_for_testing'
    }
    
    # Perform verification
    result = verifier.perform_full_verification(test_certificate)
    
    # Generate report
    report = verifier.generate_verification_report(result)
    print(report)

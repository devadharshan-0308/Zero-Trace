import sys
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QGridLayout,
    QTextEdit, QLineEdit, QPushButton, QLabel, QDialog
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QIcon

class CompletionNotification(QDialog):
    def __init__(self, parent=None, message="Data Deletion Completed", details="All files securely wiped."):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(370, 170)
        if parent:
            geo = parent.geometry()
            self.move(geo.center().x() - self.width()//2, geo.top() + 45)
        layout = QVBoxLayout(self)
        container = QWidget()
        container.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #353a50, stop:1 #585d80);
                border-radius: 20px;
                border: 2px solid #90caf9;
            }
        """)
        vbox = QVBoxLayout(container)
        title = QLabel("✅ " + message)
        title.setStyleSheet("color: #fafafa; font-size: 18px; font-weight: bold;")
        vbox.addWidget(title)
        details_lbl = QLabel("🔒 " + details)
        details_lbl.setStyleSheet("color: #e1f5fe; font-size: 14px;")
        vbox.addWidget(details_lbl)
        close_btn = QPushButton("✖ Close")
        close_btn.setStyleSheet("""
            QPushButton {
                background: #1565c0; color: white; border: none;
                padding: 7px 17px; border-radius: 8px; font-weight: bold;
            }
            QPushButton:hover { background: #003c8f; }
        """)
        close_btn.clicked.connect(self.close)
        vbox.addWidget(close_btn, alignment=Qt.AlignRight)
        layout.addWidget(container)
        QTimer.singleShot(3000, self.close)

class ChatbotWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
    def init_ui(self):
        screen = QApplication.desktop().screenGeometry()
        self.setGeometry(screen.width() - 520, 72, 480, 730)
        self.setWindowTitle("🛡 Zero Trace Professional")
        self.setWindowIcon(QIcon())

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setStyleSheet("""
            QTextEdit {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #232931, stop:1 #4ecca3);
                border-radius: 13px;
                padding: 14px;
                font-size: 14px; font-family: 'Segoe UI', Arial; color: #f5f5f5;
            }
        """)

        self.input_line = QLineEdit()
        self.input_line.setPlaceholderText(
            "Ask about secure wiping, compliance, or click a suggestion…")
        self.input_line.returnPressed.connect(self.send_message)
        self.input_line.setStyleSheet(
            "padding: 10px; border-radius: 8px; border: 2px solid #4ecca3; font-size: 14px;")

        self.send_button = QPushButton("Send")
        self.send_button.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:1, x2:1, y2:0,
                    stop:0 #6096fd, stop:1 #0079ff);
                color: white; padding: 9px 17px;
                border-radius: 8px; font-size: 14px;
            }
            QPushButton:hover { background: #3b4cca; }
        """)
        self.send_button.clicked.connect(self.send_message)

        # Bold black label for Advanced Quick Actions
        self.suggestions_label = QLabel("💡 Advanced Quick Actions")
        self.suggestions_label.setStyleSheet(
            "font-weight: bold; font-size: 16px; color: black; margin: 10px 0px;")
        self.suggestions_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.suggestions_label.setMinimumHeight(24)

        self.suggestion_grid = QGridLayout()

        quick_actions_layout = QVBoxLayout()
        quick_actions_layout.addWidget(self.suggestions_label)
        quick_actions_layout.addLayout(self.suggestion_grid)

        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(8)
        main_layout.addWidget(self.chat_display)
        main_layout.addLayout(quick_actions_layout)
        main_layout.addWidget(self.input_line)
        main_layout.addWidget(self.send_button)
        self.setLayout(main_layout)

        self.add_message(
            "Assistant",
            "👋 Welcome to <b>Zero Trace Pro</b> — Ask about secure erasure, compliance, or click a quick action below!"
        )

        self.all_questions = [
            "Sanitization Checklist",
            "Overwrite Methods",
            "Wipe SSD vs HDD",
            "Can I undo wipe?",
            "Recommend fastest method",
            "Most Secure Method",
            "Military-Grade Wipe",
            "View Certificates",
            "Prevent Recovery",
            "Overwrites Used",
            "GDPR/NIST/DoD Rules",
            "Sample Certificate",
            "Request Audit Report"
        ]
        self.update_suggestions()

    def add_message(self, sender, msg):
        colors = {"Assistant": "#90caf9", "You": "#72efa3"}
        self.chat_display.append(
            f"<b><span style='color:{colors.get(sender, '#000000')}'>{sender}:</span></b> {msg}<br>"
        )

    def update_suggestions(self):
        while self.suggestion_grid.count():
            widget = self.suggestion_grid.itemAt(0).widget()
            if widget:
                widget.deleteLater()
        for i, q in enumerate(self.all_questions):
            btn = QPushButton(q)
            btn.setStyleSheet("""
                QPushButton {
                    background: #43445c;
                    border: 2px solid #90caf9;
                    padding: 8px 11px;
                    border-radius: 9px;
                    font-size: 12px;
                    color: #fafafa;
                }
                QPushButton:hover {
                    background: #72efa3;
                    color: #232931;
                }
            """)
            btn.clicked.connect(lambda checked, txt=q: self.handle_suggestion_click(txt))
            self.suggestion_grid.addWidget(btn, i//3, i%3)

    def handle_suggestion_click(self, q):
        self.add_message("You", q)
        resp = self.get_bot_response(q)
        self.add_message("Assistant", resp)
        if "completed" in resp.lower() or "success" in resp.lower():
            self.show_completion_notification()

    def send_message(self):
        text = self.input_line.text().strip()
        if not text:
            return
        self.add_message("You", text)
        self.input_line.clear()
        resp = self.get_bot_response(text)
        self.add_message("Assistant", resp)
        if "completed" in resp.lower() or "success" in resp.lower():
            self.show_completion_notification()

    def get_bot_response(self, text):
        txt = text.strip().lower()
        responses = {
            "sanitization checklist":
                "The checklist ensures essential steps like backup review, selecting the correct sanitization method, "
                "confirmation before execution, and documentation after. It helps maintain compliance, discipline, "
                "and audit-readiness across your organization. A proper checklist prevents errors and ensures regulatory alignment.",
            "overwrite methods":
                "Overwrite methods use patterns—either random bits or prescribed sequences—to replace all data on a storage device. "
                "Standards like NIST or DoD require specific overwrite passes for assurance of irreversibility. Multiple passes improve security, especially for older drives or high-risk cases.",
            "wipe ssd vs hdd":
                "SSDs need commands like ATA Secure Erase or NIST Clear/Purge due to wear-leveling, while HDDs support full overwrites or Gutmann/DoD standards. "
                "Always select your wipe method based on media type and manufacturer. This is crucial for complete data destruction and passing audits.",
            "can i undo wipe":
                "No, a compliant wipe is permanent and cannot be reversed—data is irretrievably overwritten and deallocated. "
                "Always confirm with stakeholders and secure a backup ahead of destruction. Your company policy should require dual confirmation and pre-wipe review for sensitive assets.",
            "recommend fastest method":
                "NIST SP 800-88 'Clear' or ATA Secure Erase are the fastest, standards-compliant methods for most drives. "
                "Multi-pass wipes are slower and generally not required for modern SSDs. Efficiency meets security when you use certified, automated tools for your process.",
            "most secure method":
                "Gutmann's 35-pass method is the most thorough for obsolete drives, but combining multi-pass overwrite and cryptographic erasure is best for modern media. "
                "High-risk environments should also consider physical shredding. For certified security, document every step of the process.",
            "military-grade wipe":
                "Military-grade wipes use DoD 5220.22-M protocols or NSA standards—multi-pass, specific patterns, and verification steps. "
                "These wipe routines are required for government compliance and defense sectors. Operations must be logged, signed, and subject to strict proof for audits.",
            "view certificates":
                "Certificates are reported after successful index and method-specific wiping, listing device IDs, time, algorithm, and verification hash. "
                "These are cryptographically signed and should be stored for future compliance checks. Always review and archive certificates as part of your policy.",
            "prevent recovery":
                "Recovery is blocked by using repeated overwrites, cryptographic key destruction, and (if needed) physical destruction like shredding. "
                "Even advanced forensic tools cannot retrieve data after standards-compliant sanitization. Best practices include scheduled audits and disposal certification.",
            "overwrites used":
                "NIST uses three overwrite passes, DoD specifies three to seven with specific bit patterns, and Gutmann leverages thirty-five for legacy drives. "
                "It's essential to record which method was used for compliance and proof of effectiveness. Reference your operation logs in case of an audit.",
            "gdpr/nist/dod rules":
                "GDPR demands irreversible deletion of personal data, NIST and DoD set technical protocols for all drive types. "
                "A company policy should combine their verification, reporting, and destruction processes for full audit readiness. Regulatory fines are avoided through process discipline.",
            "sample certificate":
                "A sample cert displays device SN, algorithm used, status, timestamp, and a cryptographic signature. "
                "It's essential for proving destruction in legal cases or compliance reviews. Always verify your vendor matches this template and is accepted by auditors.",
            "request audit report":
                "Audit reports summarize wiped devices, dates, responsible operator, algorithms used, and result hashes. "
                "Regulatory audits rely on these as tamper-proof evidence. Digital signing adds further trust, and automation ensures periodic, gap-free compliance checks."
        }
        for key, value in responses.items():
            if key in txt:
                return value
        return "Please select one of the 13 main quick actions for detailed guidance."

    def show_completion_notification(self):
        self.notif = CompletionNotification(
            self, "Operation Completed",
            "All selected data securely sanitized. Certificate ready.")
        self.notif.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    win = ChatbotWindow()
    win.show()
    sys.exit(app.exec_())

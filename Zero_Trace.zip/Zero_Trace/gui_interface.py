"""
Unified SecureWipe GUI - ACTUAL DELETION VERSION
Optimized for performance with minimal imports
"""

import os
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                            QLabel, QListWidget, QPushButton, QSpinBox, 
                            QTextEdit, QFileDialog, QMessageBox)
from PyQt5.QtCore import QThread, pyqtSignal, Qt
from file_secure_wipe_optimized import FileSecureWipe

class WipeThread(QThread):
    progress_updated = pyqtSignal(str)
    wipe_completed = pyqtSignal(dict)
    
    def __init__(self, targets, passes):
        super().__init__()
        self.targets = targets
        self.passes = passes
        self.wiper = FileSecureWipe()
    
    def run(self):
        successful = 0
        failed = 0
        for file_path in self.targets:
            self.progress_updated.emit(f"Deleting: {os.path.basename(file_path)}")
            try:
                result = self.wiper.secure_delete_file(file_path, self.passes)
                if result['status'] == 'completed':
                    successful += 1
                else:
                    failed += 1
            except:
                failed += 1
        self.wipe_completed.emit({'successful': successful, 'failed': failed})

class UnifiedSecureWipeGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.selected_files = []
        self.wipe_thread = None
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("SecureWipe India - ACTUAL DELETION")
        self.setGeometry(100, 100, 800, 600)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        
        # Header
        header = QLabel("SecureWipe India - ACTUAL DELETION")
        header.setAlignment(Qt.AlignCenter)
        header.setStyleSheet("font-size: 20px; font-weight: bold; color: red; padding: 10px;")
        layout.addWidget(header)
        
        # File list section
        layout.addWidget(QLabel("Files for ACTUAL deletion:"))
        
        self.file_list = QListWidget()
        self.file_list.setMinimumHeight(200)
        layout.addWidget(self.file_list)
        
        # File management buttons
        btn_layout = QHBoxLayout()
        
        add_btn = QPushButton("Add Files")
        add_btn.clicked.connect(self.add_files)
        btn_layout.addWidget(add_btn)
        
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.clear_files)
        btn_layout.addWidget(clear_btn)
        
        layout.addLayout(btn_layout)
        
        # Controls section
        controls_layout = QHBoxLayout()
        controls_layout.addWidget(QLabel("Passes:"))
        
        self.passes_spin = QSpinBox()
        self.passes_spin.setRange(1, 10)
        self.passes_spin.setValue(3)
        controls_layout.addWidget(self.passes_spin)
        
        controls_layout.addStretch()
        
        # Main action button
        self.wipe_button = QPushButton("START ACTUAL DELETION")
        self.wipe_button.setStyleSheet("background: red; color: white; font-weight: bold; padding: 10px;")
        self.wipe_button.clicked.connect(self.start_wipe)
        self.wipe_button.setEnabled(False)
        controls_layout.addWidget(self.wipe_button)
        
        layout.addLayout(controls_layout)
        
        # Status display
        self.status_label = QLabel("Ready for ACTUAL deletion")
        self.status_label.setStyleSheet("padding: 10px; background: lightgray;")
        layout.addWidget(self.status_label)
        
        # Results display
        self.results_text = QTextEdit()
        self.results_text.setMaximumHeight(100)
        self.results_text.setReadOnly(True)
        layout.addWidget(self.results_text)
    
    def add_files(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select Files for ACTUAL Deletion")
        if files:
            for file_path in files:
                if file_path not in self.selected_files:
                    self.selected_files.append(file_path)
                    self.file_list.addItem(os.path.basename(file_path))
            self.update_ui_state()
    
    def clear_files(self):
        self.selected_files.clear()
        self.file_list.clear()
        self.update_ui_state()
    
    def update_ui_state(self):
        self.wipe_button.setEnabled(bool(self.selected_files))
    
    def start_wipe(self):
        if not self.selected_files:
            return
        
        reply = QMessageBox.critical(self, "CONFIRM ACTUAL DELETION", 
                                   f"DELETE {len(self.selected_files)} files PERMANENTLY?\n\n"
                                   f"This action CANNOT be undone!",
                                   QMessageBox.Yes | QMessageBox.No,
                                   QMessageBox.No)
        if reply != QMessageBox.Yes:
            return
        
        # Disable UI during operation
        self.wipe_button.setEnabled(False)
        
        # Start deletion thread
        self.wipe_thread = WipeThread(self.selected_files.copy(), self.passes_spin.value())
        self.wipe_thread.progress_updated.connect(self.update_progress)
        self.wipe_thread.wipe_completed.connect(self.wipe_completed)
        self.wipe_thread.start()
    
    def update_progress(self, message):
        self.status_label.setText(message)
    
    def wipe_completed(self, result):
        # Re-enable UI
        self.wipe_button.setEnabled(True)
        
        # Display results
        self.results_text.append(f"Files deleted: {result['successful']}")
        if result['failed'] > 0:
            self.results_text.append(f"Failed: {result['failed']}")
        
        # Clear file list
        self.selected_files.clear()
        self.file_list.clear()
        self.status_label.setText("Deletion completed")
        self.update_ui_state()
    
    def closeEvent(self, event):
        """Handle window close event"""
        if self.wipe_thread and self.wipe_thread.isRunning():
            reply = QMessageBox.question(self, "Operation in Progress",
                                       "A deletion operation is in progress. Exit anyway?",
                                       QMessageBox.Yes | QMessageBox.No,
                                       QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.wipe_thread.terminate()
                self.wipe_thread.wait(1000)
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

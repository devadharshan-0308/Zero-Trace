"""
Certificate Generation System for Secure Data Wiping
Generates tamper-proof PDF and JSON certificates with digital signatures
"""

import json
import os
from datetime import datetime
from typing import Dict, Optional
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.graphics.shapes import Drawing
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics import renderPDF
import qrcode
from io import BytesIO
import base64

class CertificateGenerator:
    """
    Generates tamper-proof wipe certificates in PDF and JSON formats
    """
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            spaceAfter=30,
            textColor=colors.darkblue,
            alignment=1  # Center alignment
        ))
        
        self.styles.add(ParagraphStyle(
            name='SectionHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceAfter=12,
            textColor=colors.darkgreen,
            borderWidth=1,
            borderColor=colors.darkgreen,
            borderPadding=5
        ))
        
        self.styles.add(ParagraphStyle(
            name='CertificateBody',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=6,
            leftIndent=20
        ))
    
    def generate_pdf_certificate(self, certificate_data: Dict, output_path: str) -> bool:
        """
        Generate PDF certificate with professional formatting
        """
        try:
            doc = SimpleDocTemplate(
                output_path,
                pagesize=A4,
                rightMargin=72,
                leftMargin=72,
                topMargin=72,
                bottomMargin=18
            )
            
            story = []
            
            # Header
            story.append(Paragraph("SECURE DATA WIPE CERTIFICATE", self.styles['CustomTitle']))
            story.append(Spacer(1, 20))
            
            # Certificate ID and QR Code
            cert_id = certificate_data.get('certificate_id', 'Unknown')
            story.append(Paragraph(f"<b>Certificate ID:</b> {cert_id}", self.styles['CertificateBody']))
            
            # Generate QR code for verification
            qr_code_data = self._generate_qr_code(certificate_data)
            if qr_code_data:
                story.append(Spacer(1, 10))
                story.append(qr_code_data)
            
            story.append(Spacer(1, 20))
            
            # Device Information Section
            story.append(Paragraph("DEVICE INFORMATION", self.styles['SectionHeader']))
            device_info = certificate_data.get('device_info', {})
            
            device_table_data = [
                ['Device Path:', device_info.get('device_path', 'Unknown')],
                ['Serial Number:', device_info.get('serial_number', 'Unknown')],
                ['Model:', device_info.get('model', 'Unknown')],
                ['Storage Type:', device_info.get('storage_type', 'Unknown')],
                ['Total Size:', self._format_bytes(device_info.get('total_size', 0))]
            ]
            
            device_table = Table(device_table_data, colWidths=[2*inch, 4*inch])
            device_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('BACKGROUND', (1, 0), (1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(device_table)
            story.append(Spacer(1, 20))
            
            # Wipe Details Section
            story.append(Paragraph("WIPE OPERATION DETAILS", self.styles['SectionHeader']))
            wipe_details = certificate_data.get('wipe_details', {})
            
            wipe_table_data = [
                ['Wipe Method:', wipe_details.get('method', 'Unknown')],
                ['Start Time:', self._format_datetime(wipe_details.get('start_time'))],
                ['End Time:', self._format_datetime(wipe_details.get('end_time'))],
                ['Status:', wipe_details.get('status', 'Unknown')],
                ['Verification Hash:', wipe_details.get('verification_hash', 'Unknown')[:32] + '...']
            ]
            
            wipe_table = Table(wipe_table_data, colWidths=[2*inch, 4*inch])
            wipe_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('BACKGROUND', (1, 0), (1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(wipe_table)
            story.append(Spacer(1, 20))
            
            # Compliance Section
            story.append(Paragraph("COMPLIANCE INFORMATION", self.styles['SectionHeader']))
            compliance = certificate_data.get('compliance', {})
            
            compliance_table_data = [
                ['Standard:', compliance.get('standard', 'Unknown')],
                ['Classification:', compliance.get('classification', 'Unknown')],
                ['Verification Method:', compliance.get('verification_method', 'Unknown')]
            ]
            
            compliance_table = Table(compliance_table_data, colWidths=[2*inch, 4*inch])
            compliance_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('BACKGROUND', (1, 0), (1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(compliance_table)
            story.append(Spacer(1, 20))
            
            # Digital Signature Section
            story.append(Paragraph("DIGITAL SIGNATURE", self.styles['SectionHeader']))
            signature = certificate_data.get('digital_signature', 'Unknown')
            
            story.append(Paragraph(
                f"<b>Digital Signature (SHA-256):</b><br/>"
                f"<font name='Courier' size='8'>{signature[:64]}<br/>"
                f"{signature[64:128]}<br/>"
                f"{signature[128:192]}<br/>"
                f"{signature[192:256] if len(signature) > 192 else ''}</font>",
                self.styles['CertificateBody']
            ))
            
            story.append(Spacer(1, 30))
            
            # Footer
            issuer = certificate_data.get('issuer', {})
            story.append(Paragraph(
                f"<b>Issued by:</b> {issuer.get('organization', 'SecureWipe India')}<br/>"
                f"<b>Platform:</b> {issuer.get('platform', 'Unknown')}<br/>"
                f"<b>Version:</b> {issuer.get('version', '1.0.0')}<br/>"
                f"<b>Generated:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}",
                self.styles['CertificateBody']
            ))
            
            # Verification Instructions
            story.append(Spacer(1, 20))
            story.append(Paragraph("VERIFICATION INSTRUCTIONS", self.styles['SectionHeader']))
            story.append(Paragraph(
                "This certificate can be verified using the SecureWipe verification tool or "
                "by scanning the QR code above. The digital signature ensures the certificate "
                "has not been tampered with since generation.",
                self.styles['CertificateBody']
            ))
            
            # Build PDF
            doc.build(story)
            return True
            
        except Exception as e:
            print(f"PDF generation failed: {e}")
            return False
    
    def generate_json_certificate(self, certificate_data: Dict, output_path: str) -> bool:
        """
        Generate JSON certificate with proper formatting
        """
        try:
            # Add metadata
            json_certificate = {
                'format_version': '1.0',
                'generated_at': datetime.now().isoformat(),
                'certificate': certificate_data
            }
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(json_certificate, f, indent=2, ensure_ascii=False)
            
            return True
            
        except Exception as e:
            print(f"JSON generation failed: {e}")
            return False
    
    def _generate_qr_code(self, certificate_data: Dict) -> Optional[Image]:
        """Generate QR code for certificate verification"""
        try:
            # Create verification URL or data
            verification_data = {
                'certificate_id': certificate_data.get('certificate_id'),
                'verification_hash': certificate_data.get('wipe_details', {}).get('verification_hash', '')[:16],
                'timestamp': certificate_data.get('timestamp')
            }
            
            qr_data = json.dumps(verification_data)
            
            # Generate QR code
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=10,
                border=4,
            )
            qr.add_data(qr_data)
            qr.make(fit=True)
            
            # Create QR code image
            qr_img = qr.make_image(fill_color="black", back_color="white")
            
            # Convert to ReportLab Image
            img_buffer = BytesIO()
            qr_img.save(img_buffer, format='PNG')
            img_buffer.seek(0)
            
            # Save temporarily and create Image object
            temp_path = "temp_qr.png"
            with open(temp_path, 'wb') as f:
                f.write(img_buffer.getvalue())
            
            img = Image(temp_path, width=1.5*inch, height=1.5*inch)
            
            # Clean up temp file
            try:
                os.remove(temp_path)
            except:
                pass
            
            return img
            
        except Exception as e:
            print(f"QR code generation failed: {e}")
            return None
    
    def _format_bytes(self, bytes_value: int) -> str:
        """Format bytes to human readable format"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_value < 1024.0:
                return f"{bytes_value:.2f} {unit}"
            bytes_value /= 1024.0
        return f"{bytes_value:.2f} PB"
    
    def _format_datetime(self, datetime_str: Optional[str]) -> str:
        """Format datetime string for display"""
        if not datetime_str:
            return "Unknown"
        
        try:
            dt = datetime.fromisoformat(datetime_str.replace('Z', '+00:00'))
            return dt.strftime('%Y-%m-%d %H:%M:%S UTC')
        except:
            return datetime_str
    
    def verify_pdf_certificate(self, pdf_path: str) -> Dict:
        """
        Extract and verify certificate data from PDF
        """
        # This would require PDF parsing - simplified for now
        return {
            'valid': True,
            'message': 'PDF verification not implemented in this version'
        }
    
    def verify_json_certificate(self, json_path: str) -> Dict:
        """
        Verify JSON certificate integrity
        """
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            certificate = data.get('certificate', {})
            
            # Basic validation
            required_fields = ['certificate_id', 'timestamp', 'device_info', 'wipe_details']
            for field in required_fields:
                if field not in certificate:
                    return {
                        'valid': False,
                        'message': f'Missing required field: {field}'
                    }
            
            # Check digital signature exists
            if 'digital_signature' not in certificate:
                return {
                    'valid': False,
                    'message': 'Missing digital signature'
                }
            
            return {
                'valid': True,
                'message': 'Certificate structure is valid',
                'certificate': certificate
            }
            
        except Exception as e:
            return {
                'valid': False,
                'message': f'Certificate verification failed: {e}'
            }
    
    def generate_batch_certificates(self, certificates: list, output_dir: str) -> Dict:
        """
        Generate multiple certificates in batch
        """
        results = {
            'successful': 0,
            'failed': 0,
            'errors': []
        }
        
        os.makedirs(output_dir, exist_ok=True)
        
        for i, cert_data in enumerate(certificates):
            try:
                cert_id = cert_data.get('certificate_id', f'cert_{i}')
                
                # Generate PDF
                pdf_path = os.path.join(output_dir, f"{cert_id}.pdf")
                if self.generate_pdf_certificate(cert_data, pdf_path):
                    results['successful'] += 1
                else:
                    results['failed'] += 1
                    results['errors'].append(f"PDF generation failed for {cert_id}")
                
                # Generate JSON
                json_path = os.path.join(output_dir, f"{cert_id}.json")
                if not self.generate_json_certificate(cert_data, json_path):
                    results['errors'].append(f"JSON generation failed for {cert_id}")
                
            except Exception as e:
                results['failed'] += 1
                results['errors'].append(f"Certificate {i} failed: {e}")
        
        return results

"""
Unified SecureWipe GUI
Single interface for both file-level and partition-level secure deletion
"""

import sys
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from unified_secure_wipe import UnifiedSecureWipe
import json
from datetime import datetime

class WipeThread(QThread):
    progress_updated = pyqtSignal(str)
    wipe_completed = pyqtSignal(dict)
    file_progress = pyqtSignal(int, int)
    single_progress = pyqtSignal(int)
    
    def __init__(self, wipe_type, targets, passes):
        super().__init__()
        self.wipe_type = wipe_type  # 'files' or 'partition'
        self.targets = targets  # List of files or single partition path
        self.passes = passes
        self._stop_requested = False
        self.wiper = UnifiedSecureWipe()
    
    def stop(self):
        self._stop_requested = True
        self.wiper.cancel_operation()
    
    def progress_callback(self, message):
        """Callback for partition wiping progress"""
        self.progress_updated.emit(message)
    
    def run(self):
        try:
            if self.wipe_type == 'files':
                # File deletion mode
                successful = 0
                failed = 0
                cancelled = 0
                results = []
                
                for i, file_path in enumerate(self.targets):
                    if self._stop_requested:
                        cancelled = len(self.targets) - i
                        break
                    
                    self.progress_updated.emit(f"Processing {i+1}/{len(self.targets)}: {os.path.basename(file_path)}")
                    self.file_progress.emit(i+1, len(self.targets))
                    
                    try:
                        result = self.wiper.secure_delete_file(file_path, self.passes)
                        results.append(result)
                        
                        if result['status'] == 'completed':
                            successful += 1
                        elif result['status'] == 'cancelled':
                            cancelled += 1
                        else:
                            failed += 1
                    except Exception as e:
                        failed += 1
                        results.append({'status': 'failed', 'error': str(e), 'file_path': file_path})
                
                batch_result = {
                    'type': 'files',
                    'total_files': len(self.targets),
                    'successful': successful,
                    'failed': failed,
                    'cancelled': cancelled,
                    'results': results
                }
                self.wipe_completed.emit(batch_result)
                
            elif self.wipe_type == 'partition':
                # Partition wiping mode
                result = self.wiper.secure_wipe_partition(
                    self.targets[0], 
                    self.passes,
                    progress_callback=self.progress_callback
                )
                result['type'] = 'partition'
                self.wipe_completed.emit(result)
                
        except Exception as e:
            error_result = {'status': 'failed', 'error': f"Thread error: {str(e)}"}
            self.wipe_completed.emit(error_result)

class UnifiedSecureWipeGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.wiper = UnifiedSecureWipe()
        self.selected_files = []
        self.selected_partition = None
        self.wipe_thread = None
        self.current_mode = 'files'  # 'files' or 'partition'
        self.init_ui()
        self.refresh_drives()
    
    def init_ui(self):
        self.setWindowTitle("SecureWipe India - Unified Data Destruction")
        self.setGeometry(100, 100, 900, 700)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)
        
        # Header
        header_widget = self.create_header()
        main_layout.addWidget(header_widget)
        
        # Mode Selection Tabs
        self.tab_widget = QTabWidget()
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #ccc;
                background: white;
                border-radius: 5px;
            }
            QTabBar::tab {
                padding: 10px 20px;
                margin: 2px;
            }
            QTabBar::tab:selected {
                background: #2E8B57;
                color: white;
                border-radius: 5px 5px 0 0;
            }
        """)
        
        # File Deletion Tab
        self.file_tab = self.create_file_tab()
        self.tab_widget.addTab(self.file_tab, "📄 File Deletion")
        
        # Partition Wiping Tab
        self.partition_tab = self.create_partition_tab()
        self.tab_widget.addTab(self.partition_tab, "💾 Partition Wiping")
        
        # Connect tab change signal
        self.tab_widget.currentChanged.connect(self.on_tab_changed)
        
        main_layout.addWidget(self.tab_widget)
        
        # Common Controls Section
        controls_widget = self.create_controls_section()
        main_layout.addWidget(controls_widget)
        
        # Progress Section
        progress_widget = self.create_progress_section()
        main_layout.addWidget(progress_widget)
        
        # Results Section
        results_widget = self.create_results_section()
        main_layout.addWidget(results_widget)
        
        # Menu bar
        self.create_menu_bar()
        
        # Status bar
        self.statusBar().showMessage("Ready")
        
        # Apply theme
        self.apply_theme()
    
    def create_header(self):
        """Create application header"""
        header_widget = QWidget()
        header_layout = QVBoxLayout()
        
        title_label = QLabel("🛡️ SecureWipe India")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("""
            font-size: 28px;
            font-weight: bold;
            color: #2E8B57;
            padding: 15px;
        """)
        
        subtitle_label = QLabel("Military-Grade Data Destruction System")
        subtitle_label.setAlignment(Qt.AlignCenter)
        subtitle_label.setStyleSheet("""
            font-size: 14px;
            color: #666;
            padding-bottom: 10px;
        """)
        
        header_layout.addWidget(title_label)
        header_layout.addWidget(subtitle_label)
        header_widget.setLayout(header_layout)
        
        return header_widget
    
    def create_file_tab(self):
        """Create file deletion tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Instructions
        instructions = QLabel("Select individual files or folders for secure deletion")
        instructions.setStyleSheet("padding: 10px; background: #f0f0f0; border-radius: 5px;")
        layout.addWidget(instructions)
        
        # File list
        self.file_list = QListWidget()
        self.file_list.setMinimumHeight(200)
        self.file_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.file_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.file_list.customContextMenuRequested.connect(self.show_file_context_menu)
        self.file_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 5px;
            }
            QListWidget::item {
                padding: 5px;
                border-bottom: 1px solid #eee;
            }
            QListWidget::item:selected {
                background: #2E8B57;
                color: white;
            }
        """)
        layout.addWidget(self.file_list)
        
        # File selection buttons
        button_layout = QHBoxLayout()
        
        add_files_btn = QPushButton("➕ Add Files")
        add_files_btn.clicked.connect(self.add_files)
        add_files_btn.setStyleSheet(self.get_button_style())
        button_layout.addWidget(add_files_btn)
        
        add_folder_btn = QPushButton("📁 Add Folder")
        add_folder_btn.clicked.connect(self.add_folder)
        add_folder_btn.setStyleSheet(self.get_button_style())
        button_layout.addWidget(add_folder_btn)
        
        remove_selected_btn = QPushButton("➖ Remove Selected")
        remove_selected_btn.clicked.connect(self.remove_selected_files)
        remove_selected_btn.setStyleSheet(self.get_button_style())
        button_layout.addWidget(remove_selected_btn)
        
        clear_btn = QPushButton("🗑️ Clear All")
        clear_btn.clicked.connect(self.clear_files)
        clear_btn.setStyleSheet(self.get_button_style())
        button_layout.addWidget(clear_btn)
        
        layout.addLayout(button_layout)
        
        # File count label
        self.file_count_label = QLabel("No files selected")
        self.file_count_label.setStyleSheet("padding: 5px; color: #666;")
        layout.addWidget(self.file_count_label)
        
        widget.setLayout(layout)
        return widget
    
    def create_partition_tab(self):
        """Create partition wiping tab"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Warning message
        warning_widget = QWidget()
        warning_widget.setStyleSheet("""
            background: #FFF3CD;
            border: 1px solid #FFC107;
            border-radius: 5px;
            padding: 10px;
        """)
        warning_layout = QHBoxLayout()
        
        warning_icon = QLabel("⚠️")
        warning_icon.setStyleSheet("font-size: 24px;")
        warning_layout.addWidget(warning_icon)
        
        warning_text = QLabel(
            "<b>WARNING:</b> Partition wiping will permanently destroy ALL data on the selected drive. "
            "This operation requires administrator privileges and cannot be undone!"
        )
        warning_text.setWordWrap(True)
        warning_layout.addWidget(warning_text)
        
        warning_widget.setLayout(warning_layout)
        layout.addWidget(warning_widget)
        
        # Drive selection
        drive_group = QGroupBox("Select Drive/Partition")
        drive_layout = QVBoxLayout()
        
        # Drive list
        self.drive_list = QListWidget()
        self.drive_list.setMinimumHeight(200)
        self.drive_list.itemClicked.connect(self.on_drive_selected)
        self.drive_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #ccc;
                border-radius: 5px;
                padding: 5px;
            }
            QListWidget::item {
                padding: 10px;
                border-bottom: 1px solid #eee;
            }
            QListWidget::item:selected {
                background: #DC143C;
                color: white;
            }
        """)
        drive_layout.addWidget(self.drive_list)
        
        # Refresh button
        refresh_btn = QPushButton("🔄 Refresh Drives")
        refresh_btn.clicked.connect(self.refresh_drives)
        refresh_btn.setStyleSheet(self.get_button_style())
        drive_layout.addWidget(refresh_btn)
        
        # Drive info
        self.drive_info_label = QLabel("Select a drive to view details")
        self.drive_info_label.setStyleSheet("""
            padding: 10px;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
        """)
        drive_layout.addWidget(self.drive_info_label)
        
        drive_group.setLayout(drive_layout)
        layout.addWidget(drive_group)
        
        # Admin status
        admin_status = "✅ Running as Administrator" if self.wiper.is_admin else "❌ Administrator privileges required"
        admin_label = QLabel(admin_status)
        admin_label.setStyleSheet("padding: 5px; color: #666;")
        layout.addWidget(admin_label)
        
        widget.setLayout(layout)
        return widget

"""
Simple Certificate Generator - Guaranteed to work
This module provides a simple, reliable certificate generation
"""

import os
import json
import hashlib
from datetime import datetime

# Try importing optional libraries
try:
    import qrcode
    QRCODE_AVAILABLE = True
except ImportError:
    QRCODE_AVAILABLE = False
    print("Warning: qrcode not installed. Install with: pip install qrcode[pil]")

try:
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import letter
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False
    print("Warning: reportlab not installed. Install with: pip install reportlab")


class SimpleCertificateGenerator:
    """Simple certificate generator that always works"""
    
    def __init__(self):
        self.cert_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'certificates')
        os.makedirs(self.cert_dir, exist_ok=True)
        
    def generate_all_certificates(self, operation_result):
        """Generate JSON, PDF, and QR certificates"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        cert_id = f"ZT-{timestamp}"
        
        # Create certificate data
        cert_data = {
            'certificate_id': cert_id,
            'timestamp': datetime.now().isoformat(),
            'operation_type': operation_result.get('type', 'unknown'),
            'method': operation_result.get('method', 'NIST Clear'),
            'status': operation_result.get('status', 'unknown'),
            'files_processed': operation_result.get('successful', 0) + operation_result.get('failed', 0),
            'files_deleted': operation_result.get('successful', 0),
            'files_failed': operation_result.get('failed', 0),
            'verification_hash': ''
        }
        
        # Generate hash
        cert_data['verification_hash'] = hashlib.sha256(
            json.dumps(cert_data, sort_keys=True).encode()
        ).hexdigest()[:16]  # Use first 16 chars for simplicity
        
        results = {
            'success': False,
            'files': {},
            'errors': []
        }
        
        # 1. Always generate JSON (this will always work)
        try:
            json_path = os.path.join(self.cert_dir, f'{cert_id}.json')
            with open(json_path, 'w') as f:
                json.dump(cert_data, f, indent=4)
            results['files']['json'] = json_path
            results['success'] = True
            print(f"✅ JSON certificate saved: {json_path}")
        except Exception as e:
            results['errors'].append(f"JSON generation failed: {e}")
            print(f"❌ JSON generation failed: {e}")
        
        # 2. Generate QR code if available
        if QRCODE_AVAILABLE:
            try:
                qr = qrcode.QRCode(version=1, box_size=10, border=2)
                qr_text = f"Certificate: {cert_id}\nHash: {cert_data['verification_hash']}\nStatus: {cert_data['status']}"
                qr.add_data(qr_text)
                qr.make(fit=True)
                
                qr_img = qr.make_image(fill_color="black", back_color="white")
                qr_path = os.path.join(self.cert_dir, f'{cert_id}_qr.png')
                qr_img.save(qr_path)
                results['files']['qr'] = qr_path
                print(f"✅ QR code saved: {qr_path}")
            except Exception as e:
                results['errors'].append(f"QR generation failed: {e}")
                print(f"❌ QR generation failed: {e}")
        
        # 3. Generate PDF if available
        if REPORTLAB_AVAILABLE:
            try:
                pdf_path = os.path.join(self.cert_dir, f'{cert_id}.pdf')
                c = canvas.Canvas(pdf_path, pagesize=letter)
                
                # Title
                c.setFont("Helvetica-Bold", 20)
                c.drawCentredString(300, 750, "ZERO TRACE")
                c.setFont("Helvetica-Bold", 14)
                c.drawCentredString(300, 720, "Data Sanitization Certificate")
                
                # Certificate ID
                c.setFont("Helvetica", 10)
                c.drawCentredString(300, 690, f"Certificate ID: {cert_id}")
                
                # Line
                c.line(50, 670, 550, 670)
                
                # Details
                c.setFont("Helvetica-Bold", 12)
                c.drawString(50, 640, "OPERATION DETAILS:")
                
                c.setFont("Helvetica", 11)
                details = [
                    f"Date & Time: {cert_data['timestamp']}",
                    f"Operation Type: {cert_data['operation_type'].upper()}",
                    f"Method: {cert_data['method']}",
                    f"Status: {cert_data['status'].upper()}",
                    "",
                    f"Files Processed: {cert_data['files_processed']}",
                    f"Files Deleted: {cert_data['files_deleted']}",
                    f"Files Failed: {cert_data['files_failed']}",
                    "",
                    f"Verification Hash: {cert_data['verification_hash']}"
                ]
                
                y_pos = 610
                for detail in details:
                    if detail:  # Skip empty lines
                        c.drawString(70, y_pos, detail)
                    y_pos -= 25
                
                # Add QR code if it exists
                if QRCODE_AVAILABLE and 'qr' in results['files']:
                    try:
                        c.drawImage(results['files']['qr'], 400, 400, width=150, height=150)
                        c.setFont("Helvetica", 8)
                        c.drawCentredString(475, 380, "Scan for Verification")
                    except:
                        pass
                
                # Footer
                c.setFont("Helvetica-Oblique", 9)
                c.drawCentredString(300, 50, "This certificate confirms secure data deletion")
                
                c.save()
                results['files']['pdf'] = pdf_path
                print(f"✅ PDF certificate saved: {pdf_path}")
            except Exception as e:
                results['errors'].append(f"PDF generation failed: {e}")
                print(f"❌ PDF generation failed: {e}")
        
        # Print summary
        print(f"\n📁 Certificates saved in: {self.cert_dir}")
        if results['success']:
            print(f"✅ Certificate ID: {cert_id}")
        
        return results


# Quick test function
def test_certificate_generation():
    """Test the certificate generation"""
    generator = SimpleCertificateGenerator()
    
    test_result = {
        'type': 'files',
        'status': 'completed',
        'successful': 5,
        'failed': 0,
        'method': 'NIST Clear (3 passes)'
    }
    
    result = generator.generate_all_certificates(test_result)
    
    if result['success']:
        print("\n✅ Certificate generation test PASSED!")
        print(f"Generated files:")
        for file_type, path in result['files'].items():
            print(f"  - {file_type.upper()}: {path}")
    else:
        print("\n❌ Certificate generation test FAILED!")
        for error in result['errors']:
            print(f"  - {error}")
    
    return result


if __name__ == "__main__":
    test_certificate_generation()

"""
Unified Secure Wipe Backend
Supports both individual file deletion and entire partition/drive wiping
Optimized for performance with no freezing issues
"""

import os
import sys
import time
import hashlib
import platform
import subprocess
from typing import List, Dict, Optional, Union
from pathlib import Path
import tempfile
import shutil
from datetime import datetime
import json
import threading
import random
import string
import psutil
import win32api
import win32file
import ctypes
from ctypes import wintypes

class UnifiedSecureWipe:
    """
    Unified secure deletion for files and partitions
    """
    
    def __init__(self):
        self.platform = platform.system().lower()
        self.wipe_sessions = {}
        self._cancel_flag = threading.Event()
        self.is_admin = self._check_admin_privileges()
    
    def _check_admin_privileges(self):
        """Check if running with administrator privileges"""
        if self.platform == 'windows':
            try:
                return ctypes.windll.shell32.IsUserAnAdmin() != 0
            except:
                return False
        else:
            return os.geteuid() == 0
    
    def cancel_operation(self):
        """Allow cancellation of ongoing operations"""
        self._cancel_flag.set()
    
    def reset_cancel_flag(self):
        """Reset the cancellation flag"""
        self._cancel_flag.clear()
    
    def get_available_drives(self) -> List[Dict]:
        """Get list of available drives/partitions"""
        drives = []
        
        if self.platform == 'windows':
            import win32api
            drive_bits = win32api.GetLogicalDrives()
            for letter in string.ascii_uppercase:
                if drive_bits & 1:
                    drive_path = f"{letter}:\\"
                    try:
                        drive_type = win32api.GetDriveType(drive_path)
                        volume_info = win32api.GetVolumeInformation(drive_path)
                        
                        # Get disk usage
                        usage = psutil.disk_usage(drive_path)
                        
                        drive_info = {
                            'path': drive_path,
                            'letter': letter,
                            'label': volume_info[0] if volume_info[0] else f"Local Disk ({letter}:)",
                            'filesystem': volume_info[4],
                            'type': self._get_drive_type_name(drive_type),
                            'total_size': usage.total,
                            'used_size': usage.used,
                            'free_size': usage.free,
                            'usage_percent': usage.percent,
                            'removable': drive_type == 2,
                            'can_wipe': drive_type in [2, 3]  # Removable or Fixed
                        }
                        drives.append(drive_info)
                    except:
                        pass
                drive_bits >>= 1
        else:
            # Linux/Unix partition detection
            partitions = psutil.disk_partitions()
            for partition in partitions:
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    drive_info = {
                        'path': partition.mountpoint,
                        'device': partition.device,
                        'filesystem': partition.fstype,
                        'type': 'partition',
                        'total_size': usage.total,
                        'used_size': usage.used,
                        'free_size': usage.free,
                        'usage_percent': usage.percent,
                        'removable': 'removable' in partition.opts,
                        'can_wipe': True
                    }
                    drives.append(drive_info)
                except:
                    pass
        
        return drives
    
    def _get_drive_type_name(self, drive_type: int) -> str:
        """Convert Windows drive type to readable name"""
        types = {
            0: "Unknown",
            1: "No Root Directory",
            2: "Removable",
            3: "Fixed",
            4: "Network",
            5: "CD-ROM",
            6: "RAM Disk"
        }
        return types.get(drive_type, "Unknown")
    
    def secure_delete_file(self, file_path: str, passes: int = 3) -> Dict:
        """
        Securely delete a single file with metadata clearing
        """
        self.reset_cancel_flag()
        session_id = hashlib.md5(f"{file_path}{time.time()}".encode()).hexdigest()[:8]
        
        result = {
            'session_id': session_id,
            'type': 'file',
            'file_path': file_path,
            'original_size': 0,
            'passes': passes,
            'start_time': datetime.now().isoformat(),
            'status': 'started',
            'steps_completed': [],
            'metadata_cleared': False,
            'file_overwritten': False,
            'file_deleted': False
        }
        
        try:
            if not os.path.exists(file_path):
                result['status'] = 'failed'
                result['error'] = 'File not found'
                return result
            
            result['original_size'] = os.path.getsize(file_path)
            
            # Check for cancellation
            if self._cancel_flag.is_set():
                result['status'] = 'cancelled'
                return result
            
            # Step 1: Clear file metadata and attributes
            self._clear_file_metadata(file_path, result)
            
            if self._cancel_flag.is_set():
                result['status'] = 'cancelled'
                return result
            
            # Step 2: Secure overwrite file content
            self._secure_overwrite_file(file_path, passes, result)
            
            if self._cancel_flag.is_set():
                result['status'] = 'cancelled'
                return result
            
            # Step 3: Rename file multiple times
            self._obfuscate_filename(file_path, result, iterations=2)
            
            if self._cancel_flag.is_set():
                result['status'] = 'cancelled'
                return result
            
            # Step 4: Delete file
            self._final_delete(result.get('final_path', file_path), result)
            
            result['status'] = 'completed'
            result['end_time'] = datetime.now().isoformat()
            
            self.wipe_sessions[session_id] = result
            return result
            
        except Exception as e:
            result['status'] = 'failed'
            result['error'] = str(e)
            result['end_time'] = datetime.now().isoformat()
            self.wipe_sessions[session_id] = result
            return result
    
    def secure_wipe_partition(self, drive_path: str, passes: int = 1, 
                            progress_callback=None) -> Dict:
        """
        Securely wipe an entire partition/drive
        """
        self.reset_cancel_flag()
        session_id = hashlib.md5(f"{drive_path}{time.time()}".encode()).hexdigest()[:8]
        
        result = {
            'session_id': session_id,
            'type': 'partition',
            'drive_path': drive_path,
            'passes': passes,
            'start_time': datetime.now().isoformat(),
            'status': 'started',
            'steps_completed': [],
            'files_deleted': 0,
            'folders_deleted': 0,
            'errors': []
        }
        
        try:
            # Check admin privileges for partition wiping
            if not self.is_admin:
                result['status'] = 'failed'
                result['error'] = 'Administrator privileges required for partition wiping'
                return result
            
            # Step 1: Delete all files and folders
            if progress_callback:
                progress_callback("Scanning partition for files...")
            
            total_files = 0
            total_folders = 0
            
            # Count files and folders
            for root, dirs, files in os.walk(drive_path):
                if self._cancel_flag.is_set():
                    result['status'] = 'cancelled'
                    return result
                
                total_files += len(files)
                total_folders += len(dirs)
            
            if progress_callback:
                progress_callback(f"Found {total_files} files and {total_folders} folders")
            
            # Delete files with overwriting
            processed_files = 0
            for root, dirs, files in os.walk(drive_path, topdown=False):
                if self._cancel_flag.is_set():
                    result['status'] = 'cancelled'
                    return result
                
                # Delete files in current directory
                for filename in files:
                    if self._cancel_flag.is_set():
                        result['status'] = 'cancelled'
                        return result
                    
                    file_path = os.path.join(root, filename)
                    try:
                        # Skip system files
                        if self._is_system_file(file_path):
                            continue
                        
                        # Overwrite and delete
                        if passes > 0:
                            self._quick_overwrite(file_path, passes)
                        os.remove(file_path)
                        result['files_deleted'] += 1
                        processed_files += 1
                        
                        if progress_callback and processed_files % 10 == 0:
                            progress = int((processed_files / total_files) * 100)
                            progress_callback(f"Processing files: {progress}%")
                    except Exception as e:
                        result['errors'].append(f"Failed to delete {file_path}: {str(e)}")
                
                # Delete empty directories
                for dirname in dirs:
                    if self._cancel_flag.is_set():
                        result['status'] = 'cancelled'
                        return result
                    
                    dir_path = os.path.join(root, dirname)
                    try:
                        if not self._is_system_folder(dir_path):
                            os.rmdir(dir_path)
                            result['folders_deleted'] += 1
                    except Exception as e:
                        result['errors'].append(f"Failed to delete {dir_path}: {str(e)}")
            
            result['steps_completed'].append('files_deleted')
            
            # Step 2: Wipe free space
            if progress_callback:
                progress_callback("Wiping free space...")
            
            self._wipe_free_space(drive_path, passes, progress_callback)
            result['steps_completed'].append('free_space_wiped')
            
            result['status'] = 'completed'
            result['end_time'] = datetime.now().isoformat()
            
            self.wipe_sessions[session_id] = result
            return result
            
        except Exception as e:
            result['status'] = 'failed'
            result['error'] = str(e)
            result['end_time'] = datetime.now().isoformat()
            self.wipe_sessions[session_id] = result
            return result
    
    def _is_system_file(self, file_path: str) -> bool:
        """Check if file is a system file that shouldn't be deleted"""
        system_folders = ['Windows', 'Program Files', 'Program Files (x86)', 
                         'ProgramData', 'System Volume Information', '$Recycle.Bin']
        
        for folder in system_folders:
            if folder.lower() in file_path.lower():
                return True
        return False
    
    def _is_system_folder(self, folder_path: str) -> bool:
        """Check if folder is a system folder"""
        return self._is_system_file(folder_path)
    
    def _quick_overwrite(self, file_path: str, passes: int):
        """Quick overwrite for partition wiping"""
        try:
            file_size = os.path.getsize(file_path)
            
            # Skip large files or just do single pass
            if file_size > 10 * 1024 * 1024:  # 10MB
                passes = 1
            
            with open(file_path, 'rb+') as f:
                for _ in range(passes):
                    if self._cancel_flag.is_set():
                        return
                    
                    f.seek(0)
                    # Use larger chunks for speed
                    chunk_size = 1024 * 1024  # 1MB chunks
                    chunks = file_size // chunk_size
                    
                    for _ in range(chunks):
                        f.write(os.urandom(chunk_size))
                    
                    # Write remaining bytes
                    remaining = file_size % chunk_size
                    if remaining:
                        f.write(os.urandom(remaining))
                    
                    f.flush()
                    os.fsync(f.fileno())
        except:
            pass  # Ignore errors for quick overwrite
    
    def _wipe_free_space(self, drive_path: str, passes: int, progress_callback=None):
        """Wipe free space on the drive"""
        try:
            # Get free space
            usage = psutil.disk_usage(drive_path)
            free_space = usage.free
            
            # Create temporary files to fill free space
            temp_dir = os.path.join(drive_path, f"_temp_wipe_{os.getpid()}")
            os.makedirs(temp_dir, exist_ok=True)
            
            try:
                # Fill free space with random data
                chunk_size = 100 * 1024 * 1024  # 100MB chunks
                num_files = min(10, free_space // chunk_size)
                
                for i in range(num_files):
                    if self._cancel_flag.is_set():
                        break
                    
                    temp_file = os.path.join(temp_dir, f"wipe_{i}.tmp")
                    
                    try:
                        with open(temp_file, 'wb') as f:
                            # Write random data
                            for p in range(passes):
                                if self._cancel_flag.is_set():
                                    break
                                
                                f.seek(0)
                                f.write(os.urandom(chunk_size))
                                f.flush()
                                os.fsync(f.fileno())
                                
                                if progress_callback:
                                    progress = int(((i * passes + p + 1) / (num_files * passes)) * 100)
                                    progress_callback(f"Wiping free space: {progress}%")
                    except:
                        break  # Disk full or error
                
            finally:
                # Clean up temporary files
                try:
                    shutil.rmtree(temp_dir)
                except:
                    pass
        except:
            pass
    
    def _clear_file_metadata(self, file_path: str, result: Dict):
        """Clear file metadata and attributes"""
        try:
            # Remove read-only attribute if present
            if self.platform == 'windows':
                try:
                    os.chmod(file_path, 0o777)
                except:
                    pass
            
            # Clear timestamps
            epoch_time = 0
            try:
                os.utime(file_path, (epoch_time, epoch_time))
                result['metadata_cleared'] = True
                result['steps_completed'].append('metadata_cleared')
            except:
                pass
                
        except Exception as e:
            result['steps_completed'].append(f'metadata_clear_failed: {str(e)}')
    
    def _secure_overwrite_file(self, file_path: str, passes: int, result: Dict):
        """Securely overwrite file content"""
        try:
            file_size = os.path.getsize(file_path)
            
            # Optimize for large files
            if file_size > 10 * 1024 * 1024:  # 10MB
                passes = min(passes, 1)  # Reduce passes for large files
            
            chunk_size = 256 * 1024  # 256KB chunks
            
            with open(file_path, 'rb+') as f:
                for pass_num in range(passes):
                    if self._cancel_flag.is_set():
                        return
                    
                    f.seek(0)
                    
                    # Use different patterns for each pass
                    if pass_num == 0:
                        pattern = b'\x00'  # All zeros
                    elif pass_num == 1:
                        pattern = b'\xFF'  # All ones
                    else:
                        pattern = None  # Random data
                    
                    bytes_written = 0
                    while bytes_written < file_size:
                        if self._cancel_flag.is_set():
                            return
                        
                        chunk_to_write = min(chunk_size, file_size - bytes_written)
                        
                        if pattern:
                            data = pattern * chunk_to_write
                        else:
                            data = os.urandom(chunk_to_write)
                        
                        f.write(data)
                        bytes_written += chunk_to_write
                    
                    f.flush()
                    os.fsync(f.fileno())
            
            result['file_overwritten'] = True
            result['steps_completed'].append(f'overwritten_{passes}_passes')
            
        except Exception as e:
            result['steps_completed'].append(f'overwrite_failed: {str(e)}')
    
    def _obfuscate_filename(self, file_path: str, result: Dict, iterations: int = 2):
        """Rename file multiple times to obfuscate original name"""
        try:
            current_path = file_path
            
            for i in range(iterations):
                if self._cancel_flag.is_set():
                    return
                
                # Generate random filename
                random_name = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
                dir_path = os.path.dirname(current_path)
                new_path = os.path.join(dir_path, random_name)
                
                try:
                    os.rename(current_path, new_path)
                    current_path = new_path
                except:
                    break
            
            result['final_path'] = current_path
            result['steps_completed'].append(f'filename_obfuscated_{iterations}_times')
            
        except Exception as e:
            result['final_path'] = file_path
            result['steps_completed'].append(f'obfuscation_failed: {str(e)}')
    
    def _final_delete(self, file_path: str, result: Dict):
        """Final deletion of the file"""
        try:
            if self.platform == 'windows':
                # Try normal deletion first
                try:
                    os.remove(file_path)
                except:
                    # Fallback to force delete
                    try:
                        subprocess.run(['del', '/f', '/q', file_path], 
                                     shell=True, timeout=2, check=False)
                    except:
                        pass
            else:
                os.remove(file_path)
            
            result['file_deleted'] = True
            result['steps_completed'].append('file_deleted')
            
        except Exception as e:
            result['steps_completed'].append(f'deletion_failed: {str(e)}')
    
    def generate_deletion_certificate(self, session_id: str) -> Dict:
        """Generate a deletion certificate for audit purposes"""
        if session_id not in self.wipe_sessions:
            return {'error': 'Session not found'}
        
        session = self.wipe_sessions[session_id]
        
        certificate = {
            'certificate_id': hashlib.sha256(f"{session_id}{time.time()}".encode()).hexdigest(),
            'session_id': session_id,
            'timestamp': datetime.now().isoformat(),
            'deletion_type': session.get('type', 'unknown'),
            'target': session.get('file_path') or session.get('drive_path'),
            'status': session['status'],
            'details': {
                'passes': session.get('passes'),
                'original_size': session.get('original_size'),
                'steps_completed': session.get('steps_completed', []),
                'start_time': session.get('start_time'),
                'end_time': session.get('end_time')
            }
        }
        
        if session.get('type') == 'partition':
            certificate['details']['files_deleted'] = session.get('files_deleted', 0)
            certificate['details']['folders_deleted'] = session.get('folders_deleted', 0)
            certificate['details']['errors'] = len(session.get('errors', []))
        
        return certificate

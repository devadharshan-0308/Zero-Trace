"""
Impact Dashboard for SecureWipe India
Visualizes environmental impact and user progress
"""
import json
from datetime import datetime, timedelta
from typing import Dict
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QProgressBar, QGridLayout, QGroupBox)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QPalette, QColor
from gamification_engine import GamificationEngine

class ImpactDashboard(QWidget):
    def __init__(self, user_id: str = "default_user"):
        super().__init__()
        self.user_id = user_id
        self.gamification = GamificationEngine()
        self.init_ui()
        self.load_data()
        
        # Auto-refresh timer
        self.refresh_timer = QTimer()
        self.refresh_timer.timeout.connect(self.load_data)
        self.refresh_timer.start(5000)  # Refresh every 5 seconds

    def init_ui(self):
        """Initialize the impact dashboard UI"""
        layout = QVBoxLayout()
        
        # Header
        header = QLabel("🌍 Your Environmental Impact")
        header.setAlignment(Qt.AlignCenter)
        header.setStyleSheet("font-size: 24px; font-weight: bold; color: #2E8B57; margin: 15px;")
        layout.addWidget(header)
        
        # Stats Grid
        stats_grid = QGridLayout()
        
        # Devices Wiped
        self.devices_label = self.create_stat_card("Devices Securely Wiped", "0", "💾")
        stats_grid.addWidget(self.devices_label, 0, 0)
        
        # CO2 Saved
        self.co2_label = self.create_stat_card("CO₂ Emissions Saved", "0 kg", "🌱")
        stats_grid.addWidget(self.co2_label, 0, 1)
        
        # E-Waste Prevented
        self.ewaste_label = self.create_stat_card("E-Waste Prevented", "0 kg", "♻️")
        stats_grid.addWidget(self.ewaste_label, 1, 0)
        
        # Total Points
        self.points_label = self.create_stat_card("Eco Points", "0", "⭐")
        stats_grid.addWidget(self.points_label, 1, 1)
        
        layout.addLayout(stats_grid)
        
        # Progress Section
        progress_group = QGroupBox("Your Progress")
        progress_layout = QVBoxLayout()
        
        # Level Progress
        level_layout = QHBoxLayout()
        level_layout.addWidget(QLabel("Eco Level:"))
        self.level_bar = QProgressBar()
        self.level_bar.setMaximum(100)
        self.level_bar.setStyleSheet("QProgressBar { border: 2px solid grey; border-radius: 5px; }"
                                   "QProgressBar::chunk { background-color: #4CAF50; }")
        level_layout.addWidget(self.level_bar)
        self.level_label = QLabel("1")
        level_layout.addWidget(self.level_label)
        progress_layout.addLayout(level_layout)
        
        # Next Achievement
        self.next_achievement_label = QLabel("Next: Complete your first wipe!")
        self.next_achievement_label.setStyleSheet("padding: 10px; background: #FFF3CD; border-radius: 5px;")
        progress_layout.addWidget(self.next_achievement_label)
        
        progress_group.setLayout(progress_layout)
        layout.addWidget(progress_group)
        
        # Recent Achievements
        achievements_group = QGroupBox("Recent Achievements")
        achievements_layout = QVBoxLayout()
        self.achievements_label = QLabel("No achievements yet. Start wiping to earn badges!")
        self.achievements_label.setWordWrap(True)
        achievements_layout.addWidget(self.achievements_label)
        achievements_group.setLayout(achievements_layout)
        layout.addWidget(achievements_group)
        
        # Environmental Impact Comparison
        impact_group = QGroupBox("Environmental Impact")
        impact_layout = QVBoxLayout()
        
        # CO2 equivalent explanations
        co2_info = QLabel("💡 The CO₂ you've saved is equivalent to:")
        co2_info.setStyleSheet("font-weight: bold; margin-bottom: 5px;")
        impact_layout.addWidget(co2_info)
        
        self.co2_equivalents = QLabel("• Planting 0 trees for one year\n"
                                    "• Driving 0 km in a car\n"
                                    "• Powering 0 homes for one day")
        impact_layout.addWidget(self.co2_equivalents)
        
        impact_group.setLayout(impact_layout)
        layout.addWidget(impact_group)
        
        layout.addStretch()
        self.setLayout(layout)

    def create_stat_card(self, title: str, value: str, emoji: str) -> QLabel:
        """Create a statistic card"""
        card = QLabel(f"{emoji}\n<font size='20'><b>{value}</b></font>\n{title}")
        card.setAlignment(Qt.AlignCenter)
        card.setStyleSheet("""
            QLabel {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #E8F5E8, stop:1 #C8E6C9);
                border: 2px solid #4CAF50;
                border-radius: 10px;
                padding: 15px;
                margin: 5px;
            }
        """)
        card.setMinimumHeight(100)
        return card

    def load_data(self):
        """Load and update dashboard data"""
        stats = self.gamification.get_user_stats(self.user_id)
        
        # Update basic stats
        self.devices_label.setText(f"💾\n<font size='20'><b>{stats['total_devices_wiped']}</b></font>\nDevices Securely Wiped")
        self.co2_label.setText(f"🌱\n<font size='20'><b>{stats['total_co2_saved_kg']:.1f} kg</b></font>\nCO₂ Emissions Saved")
        self.ewaste_label.setText(f"♻️\n<font size='20'><b>{stats['total_ewaste_saved_kg']:.1f} kg</b></font>\nE-Waste Prevented")
        self.points_label.setText(f"⭐\n<font size='20'><b>{stats['total_points']}</b></font>\nEco Points")
        
        # Update progress
        level_progress = min((stats['total_devices_wiped'] % 10) * 10, 100)
        self.level_bar.setValue(level_progress)
        current_level = (stats['total_devices_wiped'] // 10) + 1
        self.level_label.setText(f"Level {current_level}")
        
        # Update next achievement
        next_goal = self.get_next_goal(stats)
        self.next_achievement_label.setText(f"Next: {next_goal}")
        
        # Update achievements
        if stats['achievements']:
            achievements_text = "\n".join([f"🏆 {ach['icon']} {ach['name']} (+{ach['points']} pts)" 
                                         for ach in stats['achievements'][:3]])
            self.achievements_label.setText(achievements_text)
        
        # Update CO2 equivalents
        self.update_co2_equivalents(stats['total_co2_saved_kg'])

    def get_next_goal(self, stats: Dict) -> str:
        """Determine next achievement goal"""
        devices = stats['total_devices_wiped']
        
        if devices == 0:
            return "Complete your first secure wipe!"
        elif devices < 10:
            return f"Wipe {10 - devices} more devices to become Eco Saver"
        elif devices < 50:
            return f"Wipe {50 - devices} more devices to become Data Guardian"
        else:
            return "Reach 100 devices to become Recycling Champion!"

    def update_co2_equivalents(self, co2_kg: float):
        """Update CO2 equivalent explanations"""
        trees = co2_kg / 21.77  # Average tree absorbs 21.77kg CO2 per year
        km_driven = co2_kg / 0.12  # Average car emits 0.12kg CO2 per km
        homes_powered = co2_kg / 5.0  # Rough equivalent for home energy
        
        equivalents = (f"• Planting {trees:.0f} trees for one year\n"
                      f"• Driving {km_driven:.0f} km in a car\n"
                      f"• Powering {homes_powered:.0f} homes for one day")
        
        self.co2_equivalents.setText(equivalents)

    def record_wipe(self, device_count: int = 1, file_count: int = 0, method: str = "standard"):
        """Record a wipe operation and update dashboard"""
        result = self.gamification.record_wipe_session(
            self.user_id, device_count, file_count, method
        )
        self.load_data()
        return result

"""
File-Level Secure Deletion with Metadata Clearing
Securely deletes individual files and clears all metadata traces
"""

import os
import sys
import time
import hashlib
import platform
import subprocess
from typing import List, Dict, Optional
from pathlib import Path
import tempfile
import shutil
from datetime import datetime
import json

class FileSecureWipe:
    """
    Secure file deletion that removes all traces including metadata
    """
    
    def __init__(self):
        self.platform = platform.system().lower()
        self.wipe_sessions = {}
    
    def secure_delete_file(self, file_path: str, passes: int = 3) -> Dict:
        """
        Securely delete a single file with metadata clearing
        """
        session_id = hashlib.md5(f"{file_path}{time.time()}".encode()).hexdigest()[:8]
        
        result = {
            'session_id': session_id,
            'file_path': file_path,
            'original_size': 0,
            'passes': passes,
            'start_time': datetime.now().isoformat(),
            'status': 'started',
            'steps_completed': [],
            'metadata_cleared': False,
            'file_overwritten': False,
            'file_deleted': False
        }
        
        try:
            if not os.path.exists(file_path):
                result['status'] = 'failed'
                result['error'] = 'File not found'
                return result
            
            result['original_size'] = os.path.getsize(file_path)
            
            # Step 1: Clear file metadata and attributes
            self._clear_file_metadata(file_path, result)
            
            # Step 2: Secure overwrite file content
            self._secure_overwrite_file(file_path, passes, result)
            
            # Step 3: Rename file multiple times (obfuscate filename)
            self._obfuscate_filename(file_path, result)
            
            # Step 4: Delete file
            self._final_delete(result.get('final_path', file_path), result)
            
            # Step 5: Clear filesystem metadata
            self._clear_filesystem_metadata(file_path, result)
            
            result['status'] = 'completed'
            result['end_time'] = datetime.now().isoformat()
            
        except Exception as e:
            result['status'] = 'failed'
            result['error'] = str(e)
        
        self.wipe_sessions[session_id] = result
        return result
    
    def _clear_file_metadata(self, file_path: str, result: Dict):
        """Clear file metadata and attributes"""
        try:
            # Clear file attributes
            if self.platform == "windows":
                # Remove read-only, hidden, system attributes
                subprocess.run(f'attrib -R -H -S "{file_path}"', shell=True, capture_output=True)
                
                # Clear alternate data streams (ADS) - skip if streams.exe not available
                try:
                    subprocess.run(f'streams -s -d "{file_path}"', shell=True, capture_output=True, timeout=5)
                except:
                    pass  # Skip if streams.exe not available
                
            elif self.platform == "linux":
                # Clear extended attributes
                subprocess.run(f'setfattr -h -x user.* "{file_path}"', shell=True, capture_output=True)
                
                # Clear file capabilities
                subprocess.run(f'setcap -r "{file_path}"', shell=True, capture_output=True)
            
            # Modify timestamps to current time (removes original timestamps)
            current_time = time.time()
            os.utime(file_path, (current_time, current_time))
            
            result['steps_completed'].append('metadata_cleared')
            result['metadata_cleared'] = True
            
        except Exception as e:
            result['steps_completed'].append(f'metadata_clear_failed: {e}')
    
    def _secure_overwrite_file(self, file_path: str, passes: int, result: Dict):
        """Securely overwrite file content multiple times"""
        try:
            file_size = os.path.getsize(file_path)
            
            # Patterns for overwriting
            patterns = [
                b'\x00',  # All zeros
                b'\xFF',  # All ones
                b'\xAA',  # Alternating pattern
                b'\x55',  # Inverse alternating
            ]
            
            with open(file_path, 'r+b') as f:
                for pass_num in range(passes):
                    # Choose pattern (cycle through patterns)
                    pattern = patterns[pass_num % len(patterns)]
                    
                    # Overwrite entire file
                    f.seek(0)
                    bytes_written = 0
                    chunk_size = 64 * 1024  # 64KB chunks
                    
                    # Create pattern buffer once for efficiency
                    pattern_buffer = pattern * chunk_size
                    
                    while bytes_written < file_size:
                        remaining = min(chunk_size, file_size - bytes_written)
                        f.write(pattern_buffer[:remaining])
                        bytes_written += remaining
                    
                    # Force write to disk
                    f.flush()
                    os.fsync(f.fileno())
                    
                    result['steps_completed'].append(f'pass_{pass_num + 1}_completed')
            
            # Final random overwrite (optimized)
            with open(file_path, 'r+b') as f:
                f.seek(0)
                bytes_written = 0
                chunk_size = 1024 * 1024  # 1MB chunks for random data
                
                while bytes_written < file_size:
                    remaining = min(chunk_size, file_size - bytes_written)
                    f.write(os.urandom(remaining))
                    bytes_written += remaining
                
                f.flush()
                os.fsync(f.fileno())
            
            result['file_overwritten'] = True
            result['steps_completed'].append('secure_overwrite_completed')
            
        except Exception as e:
            result['steps_completed'].append(f'overwrite_failed: {e}')
    
    def _obfuscate_filename(self, file_path: str, result: Dict):
        """Rename file multiple times to obfuscate original filename"""
        try:
            current_path = file_path
            directory = os.path.dirname(file_path)
            
            # Rename file 5 times with random names
            for i in range(5):
                random_name = hashlib.md5(os.urandom(32)).hexdigest()[:16]
                new_path = os.path.join(directory, random_name)
                
                os.rename(current_path, new_path)
                current_path = new_path
                
                result['steps_completed'].append(f'rename_{i + 1}_completed')
            
            result['final_path'] = current_path
            result['steps_completed'].append('filename_obfuscation_completed')
            
        except Exception as e:
            result['final_path'] = file_path
            result['steps_completed'].append(f'obfuscation_failed: {e}')
    
    def _final_delete(self, file_path: str, result: Dict):
        """Final file deletion"""
        try:
            os.remove(file_path)
            result['file_deleted'] = True
            result['steps_completed'].append('file_deleted')
            
        except Exception as e:
            result['steps_completed'].append(f'delete_failed: {e}')
    
    def _clear_filesystem_metadata(self, original_path: str, result: Dict):
        """Clear filesystem-level metadata"""
        try:
            if self.platform == "windows":
                # Clear MFT entries and journal
                drive = os.path.splitdrive(original_path)[0]
                
                # Run cipher to overwrite deleted data
                subprocess.run(f'cipher /w:"{os.path.dirname(original_path)}"', 
                             shell=True, capture_output=True)
                
            elif self.platform == "linux":
                # Sync filesystem
                subprocess.run('sync', shell=True)
                
                # Clear directory entry cache
                directory = os.path.dirname(original_path)
                subprocess.run(f'find "{directory}" -name ".*" -type f -delete', 
                             shell=True, capture_output=True)
            
            result['steps_completed'].append('filesystem_metadata_cleared')
            
        except Exception as e:
            result['steps_completed'].append(f'filesystem_clear_failed: {e}')
    
    def secure_delete_multiple_files(self, file_paths: List[str], passes: int = 3) -> Dict:
        """Securely delete multiple files"""
        results = {
            'batch_id': hashlib.md5(f"{len(file_paths)}{time.time()}".encode()).hexdigest()[:8],
            'total_files': len(file_paths),
            'successful': 0,
            'failed': 0,
            'results': []
        }
        
        for file_path in file_paths:
            file_result = self.secure_delete_file(file_path, passes)
            results['results'].append(file_result)
            
            if file_result['status'] == 'completed':
                results['successful'] += 1
            else:
                results['failed'] += 1
        
        return results
    
    def secure_delete_folder_contents(self, folder_path: str, passes: int = 3, 
                                    include_subfolders: bool = False) -> Dict:
        """Securely delete all files in a folder"""
        if not os.path.exists(folder_path):
            return {'error': 'Folder not found'}
        
        file_paths = []
        
        if include_subfolders:
            for root, dirs, files in os.walk(folder_path):
                for file in files:
                    file_paths.append(os.path.join(root, file))
        else:
            file_paths = [os.path.join(folder_path, f) for f in os.listdir(folder_path) 
                         if os.path.isfile(os.path.join(folder_path, f))]
        
        return self.secure_delete_multiple_files(file_paths, passes)
    
    def generate_deletion_certificate(self, session_id: str) -> Dict:
        """Generate certificate for file deletion"""
        if session_id not in self.wipe_sessions:
            return {'error': 'Session not found'}
        
        session = self.wipe_sessions[session_id]
        
        certificate = {
            'certificate_id': f"FILE_WIPE_{session_id}",
            'timestamp': datetime.now().isoformat(),
            'file_info': {
                'original_path': session['file_path'],
                'original_size': session['original_size'],
                'deletion_method': f"{session['passes']}-pass overwrite"
            },
            'deletion_details': {
                'start_time': session['start_time'],
                'end_time': session.get('end_time'),
                'status': session['status'],
                'steps_completed': session['steps_completed'],
                'metadata_cleared': session['metadata_cleared'],
                'file_overwritten': session['file_overwritten'],
                'file_deleted': session['file_deleted']
            },
            'compliance': {
                'standard': 'DoD 5220.22-M',
                'passes': session['passes'],
                'metadata_clearing': 'Yes' if session['metadata_cleared'] else 'No'
            },
            'verification_hash': hashlib.sha256(
                json.dumps(session, sort_keys=True).encode()
            ).hexdigest()
        }
        
        return certificate

# Example usage functions
def secure_delete_single_file(file_path: str, passes: int = 3):
    """Simple function to securely delete a single file"""
    wiper = FileSecureWipe()
    result = wiper.secure_delete_file(file_path, passes)
    
    print(f"File: {file_path}")
    print(f"Status: {result['status']}")
    print(f"Steps completed: {len(result['steps_completed'])}")
    
    if result['status'] == 'completed':
        print("[OK] File securely deleted with metadata cleared")
        
        # Generate certificate
        cert = wiper.generate_deletion_certificate(result['session_id'])
        cert_file = f"deletion_cert_{result['session_id']}.json"
        
        with open(cert_file, 'w') as f:
            json.dump(cert, f, indent=2)
        
        print(f"[CERT] Certificate saved: {cert_file}")
    else:
        print(f"[ERROR] Deletion failed: {result.get('error', 'Unknown error')}")
    
    return result

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python file_secure_wipe.py <file_path> [passes]")
        print("Example: python file_secure_wipe.py 'C:\\path\\to\\file.txt' 5")
        sys.exit(1)
    
    file_path = sys.argv[1]
    passes = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    
    secure_delete_single_file(file_path, passes)

"""
PDF Certificate Generator for Zero Trace
Generates professional PDF certificates for data sanitization
"""

import os
import json
from datetime import datetime
from typing import Dict, Any

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image, PageBreak
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
    from reportlab.pdfgen import canvas
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

def install_reportlab():
    """Install reportlab if not available"""
    import subprocess
    import sys
    
    print("📦 Installing reportlab for PDF generation...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "reportlab"])
        print("✅ reportlab installed successfully!")
        return True
    except Exception as e:
        print(f"❌ Failed to install reportlab: {e}")
        print("Please install manually: pip install reportlab")
        return False

class PDFCertificateGenerator:
    """Generate professional PDF certificates for data sanitization"""
    
    def __init__(self):
        if not REPORTLAB_AVAILABLE:
            if install_reportlab():
                # Try to import again after installation
                try:
                    global SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, getSampleStyleSheet, ParagraphStyle
                    global inch, TA_CENTER, TA_LEFT, TA_JUSTIFY, canvas, colors, letter, A4
                    from reportlab.lib import colors
                    from reportlab.lib.pagesizes import letter, A4
                    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
                    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
                    from reportlab.lib.units import inch
                    from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
                    from reportlab.pdfgen import canvas
                except ImportError:
                    raise ImportError("reportlab is required for PDF generation")
            else:
                raise ImportError("reportlab is required for PDF generation")
        
        self.styles = getSampleStyleSheet()
        self._create_custom_styles()
    
    def _create_custom_styles(self):
        """Create custom styles for the certificate"""
        # Title style
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Title'],
            fontSize=24,
            textColor=colors.HexColor('#1e3a8a'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        # Heading style
        self.heading_style = ParagraphStyle(
            'CustomHeading',
            parent=self.styles['Heading1'],
            fontSize=14,
            textColor=colors.HexColor('#1e3a8a'),
            spaceAfter=12,
            fontName='Helvetica-Bold'
        )
        
        # Body style
        self.body_style = ParagraphStyle(
            'CustomBody',
            parent=self.styles['BodyText'],
            fontSize=11,
            alignment=TA_JUSTIFY,
            spaceAfter=12
        )
        
        # Certificate number style
        self.cert_number_style = ParagraphStyle(
            'CertNumber',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.grey,
            alignment=TA_CENTER
        )
    
    def generate_certificate(self, cert_data: Dict[str, Any], output_path: str) -> bool:
        """Generate a PDF certificate from the provided data"""
        try:
            # Create the PDF document
            doc = SimpleDocTemplate(
                output_path,
                pagesize=letter,
                rightMargin=72,
                leftMargin=72,
                topMargin=72,
                bottomMargin=72
            )
            
            # Build the content
            story = []
            
            # Add certificate header
            story.append(Paragraph("🔷 ZERO TRACE", self.title_style))
            story.append(Paragraph("Data Sanitization Certificate", self.title_style))
            story.append(Spacer(1, 0.2*inch))
            
            # Certificate number
            cert_number = f"Certificate No: ZT-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            story.append(Paragraph(cert_number, self.cert_number_style))
            story.append(Spacer(1, 0.3*inch))
            
            # Certification statement
            story.append(Paragraph("CERTIFICATE OF DATA DESTRUCTION", self.heading_style))
            story.append(Paragraph(
                "This certifies that the data sanitization process has been completed in accordance with "
                "industry standards and best practices for secure data destruction.",
                self.body_style
            ))
            story.append(Spacer(1, 0.2*inch))
            
            # Operation details
            story.append(Paragraph("OPERATION DETAILS", self.heading_style))
            
            # Create details table
            operation_data = [
                ['Field', 'Value'],
                ['Date & Time', datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
                ['Operation Type', cert_data.get('operation', 'Unknown').upper()],
                ['Sanitization Method', cert_data.get('method', 'NIST Clear')],
                ['Status', cert_data.get('status', 'Unknown').upper()],
            ]
            
            # Add device/file specific details
            details = cert_data.get('details', {})
            if details.get('type') == 'device':
                operation_data.extend([
                    ['Device Path', details.get('device_path', 'N/A')],
                    ['Files Wiped', str(details.get('files_deleted', 0))],
                    ['Files Failed', str(details.get('files_failed', 0))],
                    ['Files Locked', str(details.get('files_locked', 0))],
                    ['Files Skipped', str(details.get('files_skipped', 0))],
                ])
            else:
                operation_data.extend([
                    ['Total Files', str(details.get('total', 0))],
                    ['Successfully Wiped', str(details.get('successful', 0))],
                    ['Failed', str(details.get('failed', 0))],
                ])
            
            # Create and style the table
            table = Table(operation_data, colWidths=[2.5*inch, 3.5*inch])
            table.setStyle(TableStyle([
                # Header row
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a8a')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                
                # Data rows
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.grey),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                
                # Alternating row colors
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.lightgrey]),
            ]))
            
            story.append(table)
            story.append(Spacer(1, 0.3*inch))
            
            # Compliance section
            story.append(Paragraph("COMPLIANCE STANDARDS", self.heading_style))
            compliance_text = """
            This data sanitization process complies with the following standards:
            • NIST SP 800-88 Rev. 1 Guidelines for Media Sanitization
            • DoD 5220.22-M Data Sanitization Standards
            • ISO/IEC 27001:2013 Information Security Management
            """
            story.append(Paragraph(compliance_text, self.body_style))
            story.append(Spacer(1, 0.3*inch))
            
            # Verification section
            story.append(Paragraph("VERIFICATION", self.heading_style))
            verification_text = """
            The data sanitization process has been verified and confirmed complete. 
            All targeted data has been rendered unrecoverable through the application 
            of the specified sanitization method. This certificate serves as official 
            documentation of the secure data destruction process.
            """
            story.append(Paragraph(verification_text, self.body_style))
            story.append(Spacer(1, 0.3*inch))
            
            # Signature section
            story.append(Paragraph("AUTHORIZED BY", self.heading_style))
            story.append(Spacer(1, 0.2*inch))
            
            signature_data = [
                ['_' * 40, '_' * 40],
                ['Authorized Signature', 'Date'],
                ['', ''],
                ['Zero Trace Data Sanitization System', datetime.now().strftime('%Y-%m-%d')],
            ]
            
            sig_table = Table(signature_data, colWidths=[3*inch, 3*inch])
            sig_table.setStyle(TableStyle([
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 1), (-1, 1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
            ]))
            
            story.append(sig_table)
            story.append(Spacer(1, 0.3*inch))
            
            # Footer
            footer_text = f"""
            <para align="center">
            <font size="8" color="grey">
            This certificate was generated automatically by Zero Trace E-Waste Data Sanitization System<br/>
            Certificate generated on {datetime.now().strftime('%Y-%m-%d at %H:%M:%S')}<br/>
            For verification, please retain this certificate with your compliance records
            </font>
            </para>
            """
            story.append(Paragraph(footer_text, self.styles['Normal']))
            
            # Build the PDF
            doc.build(story)
            
            print(f"✅ PDF certificate generated: {output_path}")
            return True
            
        except Exception as e:
            print(f"❌ Failed to generate PDF certificate: {e}")
            return False

def generate_pdf_from_json(json_path: str, pdf_path: str = None) -> bool:
    """Generate PDF certificate from existing JSON certificate"""
    try:
        with open(json_path, 'r') as f:
            cert_data = json.load(f)
        
        if not pdf_path:
            pdf_path = json_path.replace('.json', '.pdf')
        
        generator = PDFCertificateGenerator()
        return generator.generate_certificate(cert_data, pdf_path)
        
    except Exception as e:
        print(f"❌ Failed to convert JSON to PDF: {e}")
        return False

def test_pdf_generation():
    """Test PDF certificate generation"""
    test_data = {
        'certificate_type': 'SecureWipe Deletion Certificate',
        'timestamp': datetime.now().isoformat(),
        'operation': 'device',
        'method': 'NIST SP 800-88 Clear (3 passes)',
        'status': 'completed',
        'details': {
            'type': 'device',
            'device_path': 'E:\\',
            'files_deleted': 1250,
            'files_failed': 5,
            'files_locked': 3,
            'files_skipped': 150,
            'total': 1408
        }
    }
    
    generator = PDFCertificateGenerator()
    output_path = f"test_certificate_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    
    if generator.generate_certificate(test_data, output_path):
        print(f"✅ Test certificate generated: {output_path}")
        print("📄 Open the PDF to view the certificate")
        
        # Try to open the PDF
        try:
            import webbrowser
            webbrowser.open(output_path)
        except:
            pass
    else:
        print("❌ Test certificate generation failed")

if __name__ == "__main__":
    print("🔧 Zero Trace PDF Certificate Generator")
    print("=" * 50)
    
    if not REPORTLAB_AVAILABLE:
        print("⚠️ reportlab is not installed")
        if install_reportlab():
            print("✅ reportlab installed successfully!")
        else:
            print("❌ Please install reportlab manually: pip install reportlab")
            exit(1)
    
    print("\n📝 Testing PDF generation...")
    test_pdf_generation()
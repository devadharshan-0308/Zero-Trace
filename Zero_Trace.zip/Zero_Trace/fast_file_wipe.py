"""
Fast File Secure Deletion - Optimized for Speed
For WhatsApp images and small files - should take seconds, not minutes
"""

import os
import sys
import time
import random
import string
from typing import Dict

class FastFileWipe:
    def __init__(self):
        self.platform = "windows" if os.name == 'nt' else "linux"
    
    def fast_secure_delete(self, file_path: str, passes: int = 1) -> Dict:
        """Fast secure deletion optimized for small files"""
        result = {
            'file_path': file_path,
            'status': 'started',
            'steps_completed': [],
            'start_time': time.time()
        }
        
        try:
            if not os.path.exists(file_path):
                result['status'] = 'failed'
                result['error'] = 'File not found'
                return result
            
            file_size = os.path.getsize(file_path)
            print(f"Processing: {os.path.basename(file_path)} ({file_size} bytes)")
            
            # Step 1: Quick overwrite (optimized for small files)
            self._fast_overwrite(file_path, passes, result)
            
            # Step 2: Rename file to random name
            new_path = self._quick_rename(file_path, result)
            
            # Step 3: Delete file
            os.remove(new_path)
            result['steps_completed'].append('file_deleted')
            
            result['status'] = 'completed'
            result['end_time'] = time.time()
            result['duration'] = result['end_time'] - result['start_time']
            
            print(f"✓ Completed in {result['duration']:.2f} seconds")
            
        except Exception as e:
            result['status'] = 'failed'
            result['error'] = str(e)
            print(f"✗ Failed: {e}")
        
        return result
    
    def _fast_overwrite(self, file_path: str, passes: int, result: Dict):
        """Ultra-fast overwrite for small files"""
        try:
            file_size = os.path.getsize(file_path)
            
            # For small files (< 10MB), use simple patterns
            if file_size < 10 * 1024 * 1024:  # 10MB
                patterns = [b'\x00', b'\xFF', b'\xAA']
                
                with open(file_path, 'r+b') as f:
                    for pass_num in range(min(passes, 3)):  # Max 3 passes for speed
                        pattern = patterns[pass_num % len(patterns)]
                        f.seek(0)
                        f.write(pattern * file_size)
                        f.flush()
                        result['steps_completed'].append(f'pass_{pass_num + 1}')
                
                # Final random overwrite
                with open(file_path, 'r+b') as f:
                    f.seek(0)
                    f.write(os.urandom(min(file_size, 1024 * 1024)))  # Max 1MB random
                    f.flush()
                
            else:
                # For larger files, use chunk-based approach
                chunk_size = 1024 * 1024  # 1MB chunks
                with open(file_path, 'r+b') as f:
                    f.seek(0)
                    bytes_written = 0
                    while bytes_written < file_size:
                        remaining = min(chunk_size, file_size - bytes_written)
                        f.write(b'\x00' * remaining)
                        bytes_written += remaining
                    f.flush()
            
            result['steps_completed'].append('overwrite_completed')
            
        except Exception as e:
            result['steps_completed'].append(f'overwrite_failed: {e}')
    
    def _quick_rename(self, file_path: str, result: Dict) -> str:
        """Quick filename obfuscation"""
        try:
            directory = os.path.dirname(file_path)
            
            # Generate random filename
            random_name = ''.join(random.choices(string.ascii_lowercase + string.digits, k=12))
            new_path = os.path.join(directory, random_name + '.tmp')
            
            # Rename file
            os.rename(file_path, new_path)
            result['steps_completed'].append('filename_obfuscated')
            
            return new_path
            
        except Exception as e:
            result['steps_completed'].append(f'rename_failed: {e}')
            return file_path

def fast_delete_single_file(file_path: str, passes: int = 1):
    """Simple function to quickly delete a single file"""
    wiper = FastFileWipe()
    result = wiper.fast_secure_delete(file_path, passes)
    
    print(f"\nFile: {file_path}")
    print(f"Status: {result['status']}")
    print(f"Steps: {len(result['steps_completed'])}")
    
    if result['status'] == 'completed':
        print(f"Duration: {result.get('duration', 0):.2f} seconds")
        print("[OK] File quickly and securely deleted")
    else:
        print(f"[ERROR] Deletion failed: {result.get('error', 'Unknown error')}")
    
    return result

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python fast_file_wipe.py <file_path> [passes]")
        print("Example: python fast_file_wipe.py 'image.jpg' 1")
        sys.exit(1)
    
    file_path = sys.argv[1]
    passes = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    
    fast_delete_single_file(file_path, passes)
